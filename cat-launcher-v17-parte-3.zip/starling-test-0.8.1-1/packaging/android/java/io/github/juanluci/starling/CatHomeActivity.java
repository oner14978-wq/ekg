package io.github.juanluci.starling;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/**
 * Cat Launcher's own screens: assets/cat/index.html in a WebView, with `window.CatNative` as the
 * bridge to the game. Play checks the version, the device and the name, then starts GameActivity
 * (the NativeActivity that is the game) with the player's name; the game's setup (setup/mod.rs)
 * fetches the official files from Mojang when they are not there, prepares them on the phone and
 * opens the game, showing the real error of any step that fails.
 *
 * Runs in the process ":cat": the game ends its process with its activity, and this is what the
 * player comes back to.
 */
public final class CatHomeActivity extends Activity {
    /** The player's name, handed to the game (StarlingActivity.onCreate). */
    static final String NAME = "io.github.juanluci.starling.CAT_NAME";
    /** The one Minecraft: Java Edition version this build of the game runs. */
    static final String GAME_VERSION = "26.3";
    /** The marker the game writes when every official file is fetched and checked (accounts.rs). */
    private static final String FILES_DONE = "minecraft/starling-files.json";
    private static final long NEEDED_BYTES = 2L << 30;
    private static final int PICK = 41;

    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                WebView.setDataDirectorySuffix("cat");
            } catch (IllegalStateException e) {
                // A WebView already exists in this process: as it is.
            }
        }
        super.onCreate(savedInstanceState);
        immersive();
        CatCore.attach(this);
        // Loads the engine's library and starts its bridge off the UI thread (Keystore, folders,
        // renewal of the saved sign-in); a request that comes first waits for it (CatCore.start).
        new Thread(new Runnable() {
            @Override
            public void run() {
                String why = CatCore.start(CatHomeActivity.this);
                if (!why.isEmpty()) {
                    android.util.Log.e("starling", "Cat Launcher bridge: " + why);
                }
            }
        }, "cat-core-start").start();
        web = new WebView(this);
        web.setBackgroundColor(0xFF12062A);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "CatNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Only Cat Launcher's own page: nothing else may load in a view that has the bridge.
                return !request.getUrl().toString().startsWith("file:///android_asset/cat/");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            // The page's alert() and confirm() (the recovery code, logging out) need a dialog.
            @Override
            public boolean onJsAlert(WebView v, String url, String message, final JsResult result) {
                new AlertDialog.Builder(CatHomeActivity.this)
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                result.confirm();
                            }
                        }).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, final JsResult result) {
                new AlertDialog.Builder(CatHomeActivity.this)
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                result.confirm();
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                result.cancel();
                            }
                        }).show();
                return true;
            }

            // The skin PNG and the cape the page asks for with <input type=file>.
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (chooser != null) {
                    chooser.onReceiveValue(null);
                }
                chooser = callback;
                try {
                    startActivityForResult(params.createIntent(), PICK);
                } catch (Exception e) {
                    chooser = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/cat/index.html");
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        if (request == PICK && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            chooser = null;
            return;
        }
        super.onActivityResult(request, result, data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersive();
        if (web != null) {
            // Back from the game: the page asks again what is installed.
            web.evaluateJavascript("window.catResume&&window.catResume()", null);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(window.catBack&&window.catBack())===true", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String handled) {
                if (!"true".equals(handled)) {
                    CatHomeActivity.super.onBackPressed();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void immersive() {
        View decor = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController bars = decor.getWindowInsetsController();
            if (bars != null) {
                bars.hide(WindowInsets.Type.systemBars());
                bars.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** Installed = downloaded AND prepared (the engine's answer), never just downloaded. */
    private boolean prepared() {
        JSONObject answer = ask("versions", "{}");
        org.json.JSONArray all = answer == null ? null : answer.optJSONArray("versions");
        for (int i = 0; all != null && i < all.length(); i++) {
            JSONObject v = all.optJSONObject(i);
            if (v != null && GAME_VERSION.equals(v.optString("id"))) {
                return v.optBoolean("installed");
            }
        }
        return false;
    }

    /** Why this phone cannot run the game, or null. Each line is a real check, no more. */
    private String incompatibility() {
        if (Build.VERSION.SDK_INT < 26) {
            return "O motor precisa de Android 8.0 ou mais novo (este aparelho: Android "
                    + Build.VERSION.RELEASE + ").";
        }
        boolean arm64 = false;
        for (String abi : Build.SUPPORTED_64_BIT_ABIS) {
            if ("arm64-v8a".equals(abi)) {
                arm64 = true;
            }
        }
        if (!arm64) {
            return "Este build do motor é ARM64 (arm64-v8a) e este aparelho não o executa.";
        }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_VERSION, 0x400003)) {
            return "A GPU deste aparelho não oferece Vulkan 1.1, exigido pelo motor gráfico.";
        }
        // A version the permanent registry holds as installed needs neither the engine's answer
        // nor the free-space check: JOGAR goes straight on. Anything else is checked as before.
        if (!CatRegistry.INSTALLED.equals(CatRegistry.get(this).stateOf(GAME_VERSION)) && !prepared()) {
            long free = new StatFs(getFilesDir().getPath()).getAvailableBytes();
            if (free < NEEDED_BYTES) {
                return "Pouco espaço livre: o jogo precisa de cerca de 2 GB para baixar e preparar os "
                        + "arquivos (livre: " + (free >> 20) + " MB).";
            }
        }
        return null;
    }

    /** Checks, then starts the game with the player's name. "" on success, else the reason. */
    private String start(String version, String name) {
        if (!GAME_VERSION.equals(version)) {
            return "O motor roda apenas o Minecraft Java " + GAME_VERSION + "; a versão " + version
                    + " não é suportada.";
        }
        if (name == null || !name.matches("[A-Za-z0-9_]{3,16}")) {
            return "Nome de usuário inválido para o jogo: use de 3 a 16 letras, números ou _.";
        }
        final long t0 = android.os.SystemClock.elapsedRealtime();
        String problem = incompatibility();
        android.util.Log.i("starling", "JOGAR: checks took " + (android.os.SystemClock.elapsedRealtime() - t0) + " ms");
        if (problem != null) {
            return problem;
        }
        final Intent game = new Intent(this, GameActivity.class);
        game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        game.putExtra(NAME, name);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    startActivity(game);
                    android.util.Log.i("starling", "JOGAR: game activity requested " + (android.os.SystemClock.elapsedRealtime() - t0) + " ms after the click");
                } catch (RuntimeException e) {
                    android.util.Log.e("starling", "could not start the game", e);
                }
            }
        });
        return "";
    }

    private static String nameOf(String sessionJson) {
        try {
            return new JSONObject(sessionJson).optString("u", null);
        } catch (Exception e) {
            return null;
        }
    }

    private final java.util.concurrent.atomic.AtomicBoolean refreshing =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    private final java.util.concurrent.atomic.AtomicBoolean installing =
            new java.util.concurrent.atomic.AtomicBoolean(false);

    /** One-time import of the older files/cat-installed.json list into the database. */
    private void importOldCache() {
        File f = new File(getFilesDir(), "cat-installed.json");
        if (!f.isFile()) {
            return;
        }
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(f.length(), 4096)];
            int n = in.read(b);
            org.json.JSONArray old = new org.json.JSONArray(
                    new String(b, 0, Math.max(n, 0), StandardCharsets.UTF_8));
            for (int i = 0; i < old.length(); i++) {
                String id = old.optString(i);
                if (!id.isEmpty() && CatRegistry.get(this).stateOf(id) == null) {
                    CatRegistry.get(this).markInstalled(id);
                }
            }
        } catch (Exception e) {
            android.util.Log.w("starling", "old installed list not imported", e);
        }
        f.delete();
    }

    /** The engine's own answer: ids it reports installed, or null if the engine did not answer. */
    private static org.json.JSONArray askInstalledStrict() {
        JSONObject a = ask("versions", "{}");
        if (a == null || !a.optBoolean("ok")) {
            return null;
        }
        org.json.JSONArray out = new org.json.JSONArray();
        org.json.JSONArray all = a.optJSONArray("versions");
        for (int i = 0; all != null && i < all.length(); i++) {
            JSONObject v = all.optJSONObject(i);
            if (v != null && v.optBoolean("installed")) {
                out.put(v.optString("id"));
            }
        }
        return out;
    }

    private static boolean contains(org.json.JSONArray ids, String id) {
        for (int i = 0; ids != null && i < ids.length(); i++) {
            if (id.equals(ids.optString(i))) {
                return true;
            }
        }
        return false;
    }

    /** Brings the database in line with the engine, off the calling thread; one run at a time.
     *  An engine that did not answer changes nothing: a silent engine never erases a version. */
    private void reconcileRegistry() {
        if (!refreshing.compareAndSet(false, true)) {
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    org.json.JSONArray engine = askInstalledStrict();
                    if (engine == null) {
                        return;
                    }
                    CatRegistry reg = CatRegistry.get(CatHomeActivity.this);
                    for (int i = 0; i < engine.length(); i++) {
                        reg.markInstalled(engine.optString(i));
                    }
                    if (!installing.get()) {
                        org.json.JSONArray known = reg.idsIn(CatRegistry.INSTALLED);
                        for (int i = 0; i < known.length(); i++) {
                            if (!contains(engine, known.optString(i))) {
                                reg.markDamaged(known.optString(i));
                            }
                        }
                    }
                } catch (RuntimeException e) {
                    android.util.Log.w("starling", "registry check failed", e);
                } finally {
                    refreshing.set(false);
                }
            }
        }, "cat-registry-check").start();
    }

    /** After an install starts: records INSTALLED the moment the engine says files ready and prepared. */
    private void watchInstall(final String id) {
        if (!installing.compareAndSet(false, true)) {
            return;
        }
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long end = System.currentTimeMillis() + 3L * 3600 * 1000;
                    while (System.currentTimeMillis() < end) {
                        Thread.sleep(1500);
                        if (contains(askInstalledStrict(), id)) {
                            CatRegistry.get(CatHomeActivity.this).markInstalled(id);
                            return;
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    installing.set(false);
                }
            }
        }, "cat-install-watch");
        t.setDaemon(true);
        t.start();
    }

    /** The JSON of a request to the engine's systems, or null with the reason in `why[0]`. */
    private static JSONObject ask(String method, String args) {
        try {
            return new JSONObject(CatCore.request(method, args));
        } catch (Exception e) {
            return null;
        }
    }

    private static String errorOf(JSONObject answer) {
        if (answer == null) {
            return "Resposta inválida do motor.";
        }
        return answer.optBoolean("ok") ? "" : answer.optString("error", "Erro desconhecido do motor.");
    }

    /** window.CatNative: what the page (assets/cat/index.html) calls; runs on a WebView thread. */
    private final class Bridge {
        /** Every system of the engine behind the page: `method` and a JSON object of arguments in,
         *  the system's JSON answer ({"ok":true,..} or {"ok":false,"error":..}) out. */
        @JavascriptInterface
        public String core(String method, String args) {
            return CatCore.request(method, args);
        }

        /** The versions the engine knows, from the engine (Pins::starling): [{id,type,cat,installed}]. */
        @JavascriptInterface
        public String listVersions() {
            JSONObject a = ask("versions", "{}");
            if (a != null && a.optBoolean("ok") && a.optJSONArray("versions") != null
                    && a.optJSONArray("versions").length() > 0) {
                return a.optJSONArray("versions").toString();
            }
            // The engine did not answer (it can be busy or stopped after the game closes): the
            // engine's one real version, with what the permanent registry knows about it.
            org.json.JSONArray out = new org.json.JSONArray();
            try {
                String state = CatRegistry.get(CatHomeActivity.this).stateOf(GAME_VERSION);
                JSONObject v = new JSONObject();
                v.put("id", GAME_VERSION);
                v.put("type", "release");
                v.put("cat", "recent");
                v.put("installed", CatRegistry.INSTALLED.equals(state) || CatRegistry.DAMAGED.equals(state));
                out.put(v);
            } catch (org.json.JSONException e) {
                android.util.Log.w("starling", "version list not built", e);
            }
            return out.toString();
        }

        /** Versions recorded in the permanent registry (SQLite): answered at once from storage,
         *  never from the engine, so they are there on every opening. Damaged ones stay listed. */
        @JavascriptInterface
        public String installedVersions() {
            importOldCache();
            CatRegistry reg = CatRegistry.get(CatHomeActivity.this);
            reconcileRegistry();
            return reg.idsIn(CatRegistry.INSTALLED, CatRegistry.DAMAGED).toString();
        }

        /** Opens the Diagnostics screen (logs, reports) - only when the player asks for it. */
        @JavascriptInterface
        public void openDiagnostics() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(CatHomeActivity.this, DiagnosticsActivity.class));
                }
            });
        }

        /** Versions whose install began but never finished (app closed or killed): install again
         *  to resume; every file already downloaded with a good hash is reused. */
        @JavascriptInterface
        public String interruptedVersions() {
            return CatRegistry.get(CatHomeActivity.this).idsIn(CatRegistry.INSTALLING).toString();
        }

        /** Starts the engine's real download of the official files (accounts.rs download_files:
         *  Mojang's servers, each file hash-checked, resumable). The page follows it with
         *  core("state"). "" when started, else the reason. */
        @JavascriptInterface
        public String installVersion(String id) {
            if (!GAME_VERSION.equals(id)) {
                return "O motor roda apenas o Minecraft Java " + GAME_VERSION + "; a versão " + id
                        + " não é suportada.";
            }
            if (new StatFs(getFilesDir().getPath()).getAvailableBytes() < NEEDED_BYTES && !prepared()) {
                return "Pouco espaço livre: o jogo precisa de cerca de 2 GB para baixar e preparar os arquivos.";
            }
            CatRegistry.get(CatHomeActivity.this).markInstalling(id);
            String why = errorOf(ask("install", "{}"));
            if (why.isEmpty()) {
                watchInstall(id);
            }
            return why;
        }

        /** Checks, makes sure the name has a profile in the engine, then starts the game. */
        @JavascriptInterface
        public String launch(String id, String sessionJson) {
            lastSession = sessionJson;
            String name = nameOf(sessionJson);
            if (!GAME_VERSION.equals(id)) {
                return start(id, name);
            }
            // A version the registry holds as installed was reported ready by the engine: no
            // second engine round trip (which waits for the native library) before JOGAR.
            if (!CatRegistry.INSTALLED.equals(CatRegistry.get(CatHomeActivity.this).stateOf(id))
                    && !prepared()) {
                return "NOT_INSTALLED: o Minecraft " + id + " ainda não está instalado. Baixe-o em "
                        + "Download de versões.";
            }
            if (name == null || !OfflineProfile.validName(name)) {
                return "Crie uma conta offline válida (3 a 16 letras, números ou _).";
            }
            // The engine keeps the profile; its UUID must equal the one Minecraft derives from the name.
            JSONObject made = ask("add_offline", "{\"name\":" + JSONObject.quote(name) + "}");
            String why = errorOf(made);
            if (!why.isEmpty()) {
                return why;
            }
            if (!OfflineProfile.offlineUuid(name).equals(made.optString("uuid"))) {
                return "O UUID offline do motor não confere com o do Minecraft.";
            }
            return start(id, name);
        }

        /** Deletes the official files through the engine (accounts.rs files root). */
        @JavascriptInterface
        public String removeVersion(String id) {
            if (!GAME_VERSION.equals(id)) {
                return "Versão desconhecida do motor: " + id;
            }
            if (installing.get()) {
                return "Aguarde: uma instalação está em andamento.";
            }
            String gone = errorOf(ask("remove_files", "{}"));
            if (gone.isEmpty()) {
                CatRegistry.get(CatHomeActivity.this).remove(id);
            }
            return gone;
        }

        /** The look chosen on the personalisation screen: kept, and the composed skin PNG put on the
         *  playing profile through the game's own skin store (cat_bridge.rs apply_skin). */
        @JavascriptInterface
        public String saveSkin(String json) {
            try {
                JSONObject look = new JSONObject(json);
                String png = look.optString("png", "");
                look.remove("png");
                try (OutputStream out = new FileOutputStream(new File(getFilesDir(), "cat-skin.json"))) {
                    out.write(look.toString().getBytes(StandardCharsets.UTF_8));
                }
                int comma = png.indexOf(',');
                if (!png.startsWith("data:image/png;base64,") || comma < 0) {
                    return "";
                }
                File file = new File(getFilesDir(), "cat-skin.png");
                try (OutputStream out = new FileOutputStream(file)) {
                    out.write(android.util.Base64.decode(png.substring(comma + 1), android.util.Base64.DEFAULT));
                }
                String slim = "alex".equals(look.optString("model")) ? "true" : "false";
                return errorOf(ask("apply_skin", "{\"png_path\":" + JSONObject.quote(file.getPath())
                        + ",\"slim\":" + slim + "}"));
            } catch (Exception e) {
                return "Não foi possível salvar a aparência: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void immersive() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    CatHomeActivity.this.immersive();
                }
            });
        }
    }

    private String lastSession;
}
