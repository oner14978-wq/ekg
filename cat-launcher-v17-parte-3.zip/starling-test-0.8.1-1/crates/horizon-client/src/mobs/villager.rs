//! Villagers (`Villager`): professions, sleeping, the unhappy head shake,
//! food, gossip and the raid state. Their AI is the brain in
//! `villager_brain`.
use super::{
    Mob, MobEvent, MobWorld, Species,
    anim::{Poses, State},
};
use crate::items::ItemStack;
use horizon_core::geometry::trig::Mth;
use horizon_core::random::RandomSource;
use std::f32::consts::PI;

// Villager state: `variant` type, `profession` identity (index into
// the frozen profession table), `villager_level` level, `home` the claimed job site,
// `bed` and `meeting` the claimed bed head and bell, `ints[0]` the unhappy
// counter, `ints[1]` the bed's facing while asleep (1 north, 2 south,
// 3 west, 4 east), `trade` the offers, experience and restocks.

pub const NONE: u8 = 0;
pub const NITWIT: u8 = 11;

/// Vanilla profession metadata in the frozen table.
#[derive(Debug)]
pub struct Profession {
    pub id: &'static str,
    pub trade_set: Option<&'static str>,
    pub render_index: u8,
    held: Option<horizon_world::poi::PoiType>,
    acquirable: Option<horizon_world::poi::PoiType>,
}

/// Immutable vanilla-only generation. A load-owned table replaces this before mod registration.
pub struct ProfessionTable {
    entries: Vec<Profession>,
    by_poi: [Option<u8>; 13],
}
impl ProfessionTable {
    fn vanilla() -> Self {
        use horizon_world::poi::PoiType as P;
        let entries = [
            ("none", None, None),
            ("armorer", Some("armorer"), Some(P::Armorer)),
            ("butcher", Some("butcher"), Some(P::Butcher)),
            ("cartographer", Some("cartographer"), Some(P::Cartographer)),
            ("cleric", Some("cleric"), Some(P::Cleric)),
            ("farmer", Some("farmer"), Some(P::Farmer)),
            ("fisherman", Some("fisherman"), Some(P::Fisherman)),
            ("fletcher", Some("fletcher"), Some(P::Fletcher)),
            (
                "leatherworker",
                Some("leatherworker"),
                Some(P::Leatherworker),
            ),
            ("librarian", Some("librarian"), Some(P::Librarian)),
            ("mason", Some("mason"), Some(P::Mason)),
            ("nitwit", None, None),
            ("shepherd", Some("shepherd"), Some(P::Shepherd)),
            ("toolsmith", Some("toolsmith"), Some(P::Toolsmith)),
            ("weaponsmith", Some("weaponsmith"), Some(P::Weaponsmith)),
        ]
        .into_iter()
        .enumerate()
        .map(|(i, (id, trade_set, poi))| Profession {
            id,
            trade_set,
            render_index: i as u8,
            held: poi,
            acquirable: poi,
        })
        .collect::<Vec<_>>();
        let mut by_poi = [None; 13];
        for p in &entries {
            if let Some(i) = p.acquirable.and_then(P::job_index) {
                assert!(
                    by_poi[i].replace(p.render_index).is_none(),
                    "duplicate vanilla POI"
                );
            }
        }
        Self { entries, by_poi }
    }
    pub fn entries(&self) -> &[Profession] {
        &self.entries
    }
    pub fn get(&self, index: u8) -> &Profession {
        &self.entries[index as usize % self.entries.len()]
    }
    pub fn find(&self, name: &str) -> Option<u8> {
        self.entries
            .iter()
            .find(|p| p.id == name)
            .map(|p| p.render_index)
    }
    pub(super) fn by_poi(&self, poi: horizon_world::poi::PoiType) -> Option<u8> {
        self.by_poi[poi.job_index()?]
    }
    pub(super) fn held(&self, index: u8, poi: horizon_world::poi::PoiType) -> bool {
        self.entries
            .get(usize::from(index))
            .is_some_and(|p| p.held == Some(poi))
    }
    pub(super) fn acquirable(&self, index: u8, poi: horizon_world::poi::PoiType) -> bool {
        if index == NONE {
            poi.is_job()
        } else {
            self.entries
                .get(usize::from(index))
                .is_some_and(|p| p.acquirable == Some(poi))
        }
    }
}

/// The frozen vanilla-only generation shared by the existing context-free consumers.
pub fn profession_table() -> &'static ProfessionTable {
    static TABLE: std::sync::OnceLock<ProfessionTable> = std::sync::OnceLock::new();
    TABLE.get_or_init(ProfessionTable::vanilla)
}

/// Existing u8 adapter; invalid values retain the historic wrapping behavior.
pub fn profession(index: u8) -> &'static Profession {
    profession_table().get(index)
}

/// A vanilla profession or an unresolved saved resource identity.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub enum ProfessionState {
    #[default]
    None,
    Vanilla(u8),
    Unresolved(String),
}

impl ProfessionState {
    pub fn from_index(index: u8) -> Self {
        if index == NONE {
            Self::None
        } else {
            Self::Vanilla(index)
        }
    }

    pub fn from_id(id: &str) -> Self {
        let vanilla = id
            .strip_prefix("minecraft:")
            .or_else(|| (!id.contains(':')).then_some(id));
        vanilla
            .and_then(profession_index)
            .map_or_else(|| Self::Unresolved(id.into()), Self::from_index)
    }

    pub fn index(&self) -> Option<u8> {
        match self {
            Self::None => Some(NONE),
            Self::Vanilla(index) => Some(*index),
            Self::Unresolved(_) => None,
        }
    }

    pub fn id(&self) -> String {
        match self {
            Self::None => "minecraft:none".into(),
            Self::Vanilla(index) => format!("minecraft:{}", profession(*index).id),
            Self::Unresolved(id) => id.clone(),
        }
    }
}

/// Finds the existing storage index for a bare profession name.
pub fn profession_index(name: &str) -> Option<u8> {
    profession_table().find(name)
}

pub fn register(m: &mut Mob) {
    if m.extra.villager_level == 0 {
        m.extra.villager_level = 1;
    }
    // Villager's constructor: its brain does everything, it has no goals.
    m.ai.nav.can_open_doors = true;
    m.ai.nav.can_float = true;
    m.set_required_path_length(48.0);
}

/// `LivingEntity.addParticlesAroundSelf`: five particles about the body.
pub fn particles_around(m: &mut Mob, kind: &'static str, events: &mut Vec<MobEvent>) {
    let (w, h) = (f64::from(m.width()), f64::from(m.height()));
    for _ in 0..5 {
        let at = [
            m.position.x + w * (2.0 * m.random.next_double() - 1.0),
            m.position.y + h * m.random.next_double() + 1.0,
            m.position.z + w * (2.0 * m.random.next_double() - 1.0),
        ];
        events.push(MobEvent::Particles { kind, at, count: 0 });
    }
}
/// The `villager_activity` / `baby_villager_activity` timeline.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Activity {
    Idle,
    Work,
    Play,
    Meet,
    Rest,
}
pub fn activity(m: &Mob, day_time: i64) -> Activity {
    activity_at(m.is_baby(), day_time)
}
pub fn activity_at(baby: bool, day_time: i64) -> Activity {
    let t = day_time.rem_euclid(24000);
    if baby {
        match t {
            10..3000 | 6000..10000 => Activity::Idle,
            3000..6000 | 10000..12000 => Activity::Play,
            _ => Activity::Rest,
        }
    } else {
        match t {
            10..2000 | 11000..12000 => Activity::Idle,
            2000..9000 => Activity::Work,
            9000..11000 => Activity::Meet,
            _ => Activity::Rest,
        }
    }
}
pub fn sleeping(m: &Mob) -> bool {
    matches!(m.species(), Species::Villager | Species::WanderingTrader) && m.extra.ints[1] != 0
}
/// `LivingEntity.startSleeping`: lie in the bed (`setPosToBed`), whose
/// head becomes `occupied`.
pub fn start_sleeping(m: &mut Mob, p: [i32; 3], w: &MobWorld, events: &mut Vec<MobEvent>) -> bool {
    if w.prop(p[0], p[1], p[2], "occupied") == Some("true") {
        return false;
    }
    m.extra.ints[1] = bed_facing_code(w.prop(p[0], p[1], p[2], "facing"));
    m.nav_stop();
    let e = ext_mut(m);
    e.last_slept = Some(w.game_time);
    e.sleeping_pos = Some(p);
    events.push(MobEvent::BedOccupied {
        pos: p,
        occupied: true,
    });
    m.velocity = horizon_core::geometry::Vec3::ZERO;
    m.position = crate::bed_geometry::pos_to_bed(p, 0.5625);
    true
}
/// `LivingEntity.baseTick`: first-tick `setPosToBed` for a loaded sleeper.
/// Reuse normal sleep positioning without its motion, memory or bed events.
pub(super) fn refresh_sleeping_position(m: &mut Mob, w: &MobWorld) {
    if let Some(position) = sleeping_pos(m).and_then(|p| w.sleeping_position(p)) {
        m.position = position;
    }
}
/// `LivingEntity.stopSleeping`: the bed is no longer `occupied`, and the
/// sleeper stands at `AbstractBedBlock.findStandUpPosition` for its yaw,
/// else 0.1 above the block over the bed.
pub fn stop_sleeping(m: &mut Mob, w: &MobWorld, events: &mut Vec<MobEvent>) {
    m.extra.ints[1] = 0;
    let bed = m
        .extra
        .villager
        .as_deref_mut()
        .and_then(|e| e.sleeping_pos.take());
    let Some(p) = bed else { return };
    if !w.block_name(p[0], p[1], p[2]).ends_with("_bed") {
        return;
    }
    events.push(MobEvent::BedOccupied {
        pos: p,
        occupied: false,
    });
    let level = crate::stand_up::StandUpLevel {
        world: w.world,
        registry: w.registry,
        facts: w.facts,
        collision: w.collision,
        block_tags: w.block_tags,
        border: w.border,
    };
    let forward = crate::stand_up::bed_forward(w.prop(p[0], p[1], p[2], "facing"));
    let stand = level
        .bed_stand_up(crate::stand_up::StandUpType::VILLAGER, p, forward, m.yaw)
        .unwrap_or_else(|| crate::stand_up::stand_up_fallback(p));
    set_wake_pose(m, p, stand);
}
/// Rotation part of `LivingEntity.stopSleeping`, after choosing where to stand.
fn set_wake_pose(m: &mut Mob, bed: [i32; 3], stand: horizon_core::geometry::Vec3) {
    use horizon_core::geometry::{Vec3, trig};
    let d = Vec3::new(
        f64::from(bed[0]) + 0.5,
        f64::from(bed[1]),
        f64::from(bed[2]) + 0.5,
    )
    .subtract(stand)
    .normalize();
    let mut yaw = (trig::atan2(d.z, d.x) * f64::from(trig::RAD_TO_DEG) - 90.0) % 360.0;
    if yaw >= 180.0 {
        yaw -= 360.0;
    }
    if yaw < -180.0 {
        yaw += 360.0;
    }
    m.position = stand;
    m.yaw = yaw as f32;
    m.head_pitch = 0.0;
}
/// `LivingEntity.getSleepingPos`: the bed head a sleeper lies in.
pub fn sleeping_pos(m: &Mob) -> Option<[i32; 3]> {
    ext(m).and_then(|e| e.sleeping_pos).filter(|_| sleeping(m))
}
/// `LivingEntityRenderer.sleepDirectionToRotation` and the bed's direction
/// (the body is shifted back from the pillow by the standing eye height).
/// A bed's `facing` as `sleep_pose` keeps it in `ints[1]`.
pub fn bed_facing_code(facing: Option<&str>) -> i32 {
    match facing {
        Some("north") => 1,
        Some("south") => 2,
        Some("west") => 3,
        _ => 4,
    }
}
pub fn sleep_pose(m: &Mob) -> Option<(f32, [f32; 2])> {
    Some(match m.extra.ints[1] {
        1 => (270.0, [0.0, -1.0]),
        2 => (90.0, [0.0, 1.0]),
        3 => (0.0, [-1.0, 0.0]),
        4 => (180.0, [1.0, 0.0]),
        _ => return None,
    })
}
/// `Villager.tick` after `super.tick()`, with or without AI: the unhappy
/// counter counts down and the gossip decays once a day.
pub fn tick(m: &mut Mob, now: i64) {
    if m.extra.ints[0] > 0 {
        m.extra.ints[0] -= 1;
    }
    ext_mut(m).maybe_decay(now);
}
/// A hurt sleeper wakes up (`LivingEntity.hurtServer`; the `checkBedExists`
/// wake runs earlier in `LivingEntity.tick`, for AI-less mobs too), and lies
/// the way its bed faces (`getBedOrientation`). The brain does the rest.
pub fn ai_step(m: &mut Mob, w: &MobWorld, events: &mut Vec<MobEvent>) {
    if sleeping(m) {
        let bed = sleeping_pos(m).filter(|p| w.block_name(p[0], p[1], p[2]).ends_with("_bed"));
        if let Some(p) = bed {
            m.extra.ints[1] = bed_facing_code(w.prop(p[0], p[1], p[2], "facing"));
        }
        if m.hurt_time > 0 {
            stop_sleeping(m, w, events);
            super::villager_brain::woken(m, w.game_time);
        }
    }
}
/// `Villager.setUnhappy`: shake the head for two seconds and say no.
pub fn set_unhappy(m: &mut Mob, events: &mut Vec<MobEvent>) {
    m.extra.ints[0] = 40;
    let sound = if m.species() == Species::WanderingTrader {
        "entity.wandering_trader.no"
    } else {
        "entity.villager.no"
    };
    // Mob.makeSound: the sound volume and the voice pitch (babies ~1.5).
    m.voice(sound, events);
}
/// `VillagerModel.setupAnim`.
pub fn anim(m: &Mob, s: &State, p: &mut Poses) {
    let awake = !sleeping(m);
    p.yrot("head", if awake { s.y_rot.to_radians() } else { 0.0 });
    p.xrot("head", if awake { s.x_rot.to_radians() } else { 0.0 });
    if m.extra.ints[0] > 0 {
        p.zrot("head", 0.3 * (0.45 * s.age).msin());
        p.xrot("head", 0.4);
    } else {
        p.zrot("head", 0.0);
    }
    let leg = (s.pos * 0.6662).mcos() * 1.4 * s.speed * 0.5;
    p.xrot("right_leg", leg);
    p.xrot(
        "left_leg",
        (s.pos * 0.6662 + PI).mcos() * 1.4 * s.speed * 0.5,
    );
    p.yrot("right_leg", 0.0);
    p.yrot("left_leg", 0.0);
}

// ---- Raids: the raid activities and the gift for a hero.

/// No raid where the villager stands (`ServerLevel.getRaidAt` is null).
pub const RAID_NONE: u8 = 0;
/// A raid is near, before or between its waves.
pub const PRE_RAID: u8 = 1;
/// A raid is near and a wave is on.
pub const RAID: u8 = 2;
/// The raid there was won: the villagers celebrate.
pub const RAID_VICTORY: u8 = 3;
/// The raid there was lost (still found by `getRaidAt` until it stops).
pub const RAID_LOSS: u8 = 4;

/// Villager state beyond `Extra`'s scratch fields.
#[derive(Clone, Debug, Default)]
pub struct Ext {
    /// The raid `getRaidAt` finds where the villager stands (`RAID_NONE`
    /// ... `RAID_LOSS`), set by the game every tick.
    pub raid: u8,
    /// That raid has spawned a wave and is not between waves
    /// (`hasFirstWaveSpawned && !isBetweenWaves`).
    pub raid_wave: bool,
    /// What the villager remembers of players (`gossips`).
    pub gossips: crate::gossip::Gossips,
    /// `Villager.lastTradedPlayer`: the most recent trader, consumed by the
    /// next customServerAiStep. This is runtime state, not saved gossip.
    pub last_traded_player: Option<[i32; 4]>,
    pub last_gossip_time: i64,
    pub last_gossip_decay: i64,
    /// `foodLevel`: eaten but not yet digested, in food points.
    pub food_level: i32,
    /// The eight-slot inventory (`InventoryCarrier`).
    pub inventory: Vec<ItemStack>,
    /// `LAST_SLEPT` memory.
    pub last_slept: Option<i64>,
    /// `LivingEntity.getSleepingPos`: the bed head it lies in, saved as
    /// `sleeping_pos`.
    pub sleeping_pos: Option<[i32; 3]>,
    /// `GOLEM_DETECTED_RECENTLY` expires at this game time.
    pub golem_until: i64,
    /// The `last_hurt_by_time` of the player's hit already counted.
    pub hurt_seen: i32,
    /// A zombie villager's cure under way.
    pub cure: Option<super::zombie_villager::Cure>,
    /// `CanContinueSleepingEvent.mayContinueSleeping`, set by the game before the tick
    /// when a native mod may overwrite the bed check; empty means vanilla's.
    pub may_continue_sleeping: Option<bool>,
    /// `ZombieVillager.villagerDataFinalized`: only a save with
    /// `VillagerDataFinalized` or `VillagerData` sets it.
    pub data_finalized: bool,
    /// The villager's brain, built at its first tick.
    pub brain: Option<Box<super::villager_brain::Brain>>,
    /// Saved memories awaiting the first brain initialization.
    pub saved_memories: Option<Box<super::villager_brain::Memories>>,
}
pub fn ext(m: &Mob) -> Option<&Ext> {
    m.extra.villager.as_deref()
}
pub fn ext_mut(m: &mut Mob) -> &mut Ext {
    m.extra.villager.get_or_insert_with(Box::default)
}
/// The raid where the villager stands (`RAID_NONE` ... `RAID_LOSS`).
pub fn raid_status(m: &Mob) -> u8 {
    ext(m).map_or(RAID_NONE, |e| e.raid)
}
/// `ServerLevel.getRaidAt(blockPosition)` is a raid.
pub fn raid_nearby(m: &Mob) -> bool {
    ext(m).is_some_and(|e| e.raid != RAID_NONE)
}
/// `ResetRaidStatus`: no raid, a stopped one or a lost one.
pub fn raid_over_or_lost(m: &Mob) -> bool {
    matches!(raid_status(m), RAID_NONE | RAID_LOSS)
}
/// `SetRaidStatus`: `Some(true)` while a wave is on
/// (`hasFirstWaveSpawned && !isBetweenWaves`), `Some(false)` otherwise.
pub fn raid_state(m: &Mob) -> Option<bool> {
    let e = ext(m)?;
    (e.raid != RAID_NONE).then_some(e.raid_wave)
}
/// `Villager.getVillagerXp`.
pub fn xp(m: &Mob) -> i32 {
    m.extra.trade.as_ref().map_or(0, |t| t.xp)
}
/// `Villager.setVillagerData(withProfession)`: a new profession forgets the
/// offers (`offers = null`), so the next `getOffers` rolls the new
/// profession's trades.
pub fn set_profession(m: &mut Mob, profession: u8) {
    if m.extra.profession.index() != Some(profession) {
        m.extra.profession = ProfessionState::from_index(profession);
        if let Some(t) = m.extra.trade.as_mut() {
            t.offers.clear();
            t.unset = true;
        }
    }
}
/// `VillagerProfession.workSound`.
pub fn work_sound(index: u8) -> Option<&'static str> {
    Some(match profession(index).id {
        "armorer" => "entity.villager.work_armorer",
        "butcher" => "entity.villager.work_butcher",
        "cartographer" => "entity.villager.work_cartographer",
        "cleric" => "entity.villager.work_cleric",
        "farmer" => "entity.villager.work_farmer",
        "fisherman" => "entity.villager.work_fisherman",
        "fletcher" => "entity.villager.work_fletcher",
        "leatherworker" => "entity.villager.work_leatherworker",
        "librarian" => "entity.villager.work_librarian",
        "mason" => "entity.villager.work_mason",
        "shepherd" => "entity.villager.work_shepherd",
        "toolsmith" => "entity.villager.work_toolsmith",
        "weaponsmith" => "entity.villager.work_weaponsmith",
        _ => return None,
    })
}
/// A `CropBlock` at `p`.
pub fn crop(w: &MobWorld, p: [i32; 3]) -> bool {
    w.facts
        .get(w.world.block(p[0], p[1], p[2]))
        .has_class("CropBlock")
}
/// `CropBlock.isMaxAge` for the block at `p`.
pub fn ripe_crop(w: &MobWorld, p: [i32; 3]) -> bool {
    let facts = w.facts.get(w.world.block(p[0], p[1], p[2]));
    if !facts.has_class("CropBlock") {
        return false;
    }
    // The class chain survives content registration, including the two
    // getMaxAge overrides. PitcherCropBlock is not a CropBlock.
    let max = if facts.has_class("BeetrootBlock") {
        3
    } else if facts.has_class("TorchflowerCropBlock") {
        2
    } else {
        7
    };
    w.prop(p[0], p[1], p[2], "age")
        .and_then(|age| age.parse::<i32>().ok())
        .is_some_and(|age| age >= max)
}

/// The gift loot table of a villager (`GiveGiftToHero.getLootTableToThrow`).
pub fn gift_table(m: &Mob) -> String {
    if m.is_baby() {
        return "minecraft:gameplay/hero_of_the_village/baby_gift".into();
    }
    let profession = profession(m.extra.profession.index().unwrap_or(0)).id;
    let name = match profession {
        "none" | "nitwit" => "unemployed",
        other => other,
    };
    format!("minecraft:gameplay/hero_of_the_village/{name}_gift")
}
// ---- Gossip, food, breeding and golems.

/// `VillagerFood` nutrition (`DataComponents.VILLAGER_FOOD`).
///
/// The item registry's value: a data pack's or a mod's item with the component
/// counts, as one with vanilla's four does. Until a registry is loaded (tests)
/// those four.
pub fn food_points(item: &str) -> i32 {
    horizon_items::items::villager_food(item).unwrap_or(match item {
        "minecraft:bread" => 4,
        "minecraft:potato" | "minecraft:carrot" | "minecraft:beetroot" => 1,
        _ => 0,
    })
}
/// The farmer's `requestedItems` (`VillagerProfession.FARMER`). Food is picked
/// up and traded separately, through its villager food value.
pub fn farmer_items() -> &'static [&'static str] {
    &[
        "minecraft:wheat",
        "minecraft:wheat_seeds",
        "minecraft:beetroot_seeds",
        "minecraft:bone_meal",
    ]
}
/// A villager's `requestedItems` by profession.
pub fn requested_items(m: &Mob) -> &'static [&'static str] {
    if profession(m.extra.profession.index().unwrap_or(0)).id == "farmer" {
        farmer_items()
    } else {
        &[]
    }
}
pub fn is_farmer(m: &Mob) -> bool {
    profession(m.extra.profession.index().unwrap_or(0)).id == "farmer"
}
/// `SimpleContainer(8)`: stacks the villager carries.
const INVENTORY_SLOTS: usize = 8;

/// `SimpleContainer.addItem` on a container of `slots` slots held as its
/// occupied stacks in slot order: fill the stacks of the same item and
/// components below `max_stack`, then free slots; the part that did not fit
/// is returned.
pub(crate) fn add_to_container(
    inventory: &mut Vec<ItemStack>,
    mut stack: ItemStack,
    max_stack: u32,
    slots: usize,
) -> Option<ItemStack> {
    for s in inventory.iter_mut() {
        if stack.count > 0 && s.same_item_same_components(&stack) && s.count < max_stack {
            let n = (max_stack - s.count).min(stack.count);
            s.count += n;
            stack.count -= n;
        }
    }
    while stack.count > 0 && inventory.len() < slots {
        let n = stack.count.min(max_stack);
        inventory.push(ItemStack {
            count: n,
            ..stack.clone()
        });
        stack.count -= n;
    }
    (stack.count > 0).then_some(stack)
}

/// `SimpleContainer.fromItemList`: clear, then `addItem` each saved stack
/// at the type's limit for it; what does not fit is dropped.
pub(crate) fn load_container(
    m: &Mob,
    items: &[horizon_core::nbt::Tag],
    slots: usize,
) -> Vec<ItemStack> {
    let mut inventory = Vec::new();
    for stack in items.iter().filter_map(crate::save::item_from_nbt) {
        let max = m.kind.inventory_stack_limit(&stack);
        let _ = add_to_container(&mut inventory, stack, max, slots);
    }
    inventory
}

impl Ext {
    /// `countFoodPointsInInventory`.
    pub fn food_in_inventory(&self) -> i32 {
        self.inventory
            .iter()
            .map(|s| food_points(&s.item) * s.count as i32)
            .sum()
    }
    /// `hasExcessFood` and `wantsMoreFood`.
    pub fn has_excess_food(&self) -> bool {
        self.food_in_inventory() >= 24
    }
    pub fn wants_more_food(&self) -> bool {
        self.food_in_inventory() < 12
    }
    fn hungry(&self) -> bool {
        self.food_level < 12
    }
    /// `Villager.eatAndDigestFood`: eat until full, then digest 12 points.
    pub fn eat_and_digest(&mut self) {
        if self.hungry() {
            let mut slot = 0;
            while slot < self.inventory.len() && self.hungry() {
                let points = food_points(&self.inventory[slot].item);
                if points > 0 {
                    while self.inventory[slot].count > 0 && self.hungry() {
                        self.food_level += points;
                        self.inventory[slot].count -= 1;
                    }
                    if self.inventory[slot].count == 0 {
                        self.inventory.remove(slot);
                        continue;
                    }
                }
                slot += 1;
            }
        }
        self.food_level -= 12;
    }
    /// Whether the stack fits (`SimpleContainer.canAddItem`).
    pub fn can_add(&self, stack: &ItemStack, max_stack: u32) -> bool {
        self.inventory.len() < INVENTORY_SLOTS
            || self
                .inventory
                .iter()
                .any(|s| s.same_item_same_components(stack) && s.count < max_stack)
    }
    /// `SimpleContainer.addItem`: merge into stacks, then free slots; the
    /// part that did not fit is returned.
    pub fn add_item(&mut self, stack: ItemStack, max_stack: u32) -> Option<ItemStack> {
        add_to_container(&mut self.inventory, stack, max_stack, INVENTORY_SLOTS)
    }
    /// `SimpleContainer.removeItemType`: take up to `count` of the item from
    /// the first stacks that hold it.
    pub fn remove_item(&mut self, item: &str, mut count: u32) {
        let mut slot = 0;
        while slot < self.inventory.len() && count > 0 {
            let s = &mut self.inventory[slot];
            if &*s.item == item {
                let n = s.count.min(count);
                s.count -= n;
                count -= n;
                if s.count == 0 {
                    self.inventory.remove(slot);
                    continue;
                }
            }
            slot += 1;
        }
    }
    pub fn count_item(&self, item: &str) -> u32 {
        self.inventory
            .iter()
            .filter(|s| &*s.item == item)
            .map(|s| s.count)
            .sum()
    }
    /// `TradeWithVillager.throwHalfStack`: the half of a big matching stack
    /// (or whatever is over 24) leaves the inventory.
    pub fn take_half_stack(
        &mut self,
        wanted: impl Fn(&ItemStack) -> bool,
        max_stack: impl Fn(&str) -> u32,
    ) -> Option<ItemStack> {
        for i in 0..self.inventory.len() {
            let s = &self.inventory[i];
            if s.count == 0 || !wanted(s) {
                continue;
            }
            let count = if s.count > max_stack(&s.item) / 2 {
                s.count / 2
            } else if s.count > 24 {
                s.count - 24
            } else {
                continue;
            };
            let taken = ItemStack { count, ..s.clone() };
            self.inventory[i].count -= count;
            if self.inventory[i].count == 0 {
                self.inventory.remove(i);
            }
            return Some(taken);
        }
        None
    }
    /// `Villager.wantsToSpawnGolem`: slept within the last day and no golem
    /// seen lately.
    pub fn wants_golem(&self, now: i64) -> bool {
        self.last_slept.is_some_and(|t| now - t < 24000) && now >= self.golem_until
    }
    /// `maybeDecayGossip`: once a day.
    pub fn maybe_decay(&mut self, now: i64) {
        if self.last_gossip_decay == 0 {
            self.last_gossip_decay = now;
        } else if now >= self.last_gossip_decay + 24000 {
            self.gossips.decay();
            self.last_gossip_decay = now;
        }
    }
    /// `Villager.gossip` timing: hearing again waits 1200 ticks.
    pub fn can_gossip(&self, now: i64) -> bool {
        now < self.last_gossip_time || now >= self.last_gossip_time + 1200
    }
}
/// What a villager ticking later reads of another one this tick (vanilla
/// reads the other villager itself).
#[derive(Clone, Debug, Default)]
pub struct Seen {
    pub gossips: crate::gossip::Gossips,
    pub last_gossip_time: i64,
    /// `countFoodPointsInInventory`.
    pub food_points: i32,
    /// The `INTERACTION_TARGET` memory (play tag's chases).
    pub interaction_target: Option<super::Who>,
    /// The `PATH` memory, when not done: its previous and next nodes.
    pub path_nodes: Option<(Option<[i32; 3]>, [i32; 3])>,
    /// `LAST_SLEPT` and whether `GOLEM_DETECTED_RECENTLY` is remembered.
    pub last_slept: Option<i64>,
    pub golem_detected: bool,
}
impl Seen {
    /// `Villager.wantsToSpawnGolem`.
    pub fn wants_golem(&self, now: i64) -> bool {
        self.last_slept.is_some_and(|t| now - t < 24000) && !self.golem_detected
    }
    /// `Villager.wantsMoreFood`.
    pub fn wants_more_food(&self) -> bool {
        self.food_points < 12
    }
}
pub fn seen(m: &Mob) -> Seen {
    let e = ext(m);
    let (interaction_target, path_nodes, golem_detected, last_slept) =
        super::villager_brain::seen_memories(m);
    Seen {
        gossips: e.map(|e| e.gossips.clone()).unwrap_or_default(),
        last_gossip_time: e.map_or(0, |e| e.last_gossip_time),
        food_points: e.map_or(0, Ext::food_in_inventory),
        interaction_target,
        path_nodes,
        last_slept: last_slept.or(e.and_then(|e| e.last_slept)),
        golem_detected,
    }
}
/// What `TradeWithVillager.tick` hands over: stacks tossed from the first
/// villager's hand (`from`, its eye height) toward the second (`to`), and
/// whether the gossip happened (`spawnGolemIfNeeded` follows).
pub struct Meeting {
    pub thrown: Vec<ItemStack>,
    pub from: horizon_core::geometry::Vec3,
    pub eye: f64,
    pub to: horizon_core::geometry::Vec3,
    pub gossiped: bool,
}
/// `TradeWithVillager.tick` for villagers `a` and `b` (indices into `mobs`):
/// `Villager.gossip` (at most once in 1200 ticks for both), then surplus
/// food and wanted wares taken out of `a`'s inventory.
pub fn meet(
    mobs: &mut crate::join_seq::JoinList<Mob>,
    a: usize,
    b: usize,
    now: i64,
    max_stack: impl Fn(&str) -> u32,
) -> Meeting {
    let ready = ext(&mobs[a]).is_none_or(|e| e.can_gossip(now))
        && ext(&mobs[b]).is_none_or(|e| e.can_gossip(now));
    if ready {
        let source = ext(&mobs[b]).map(|e| e.gossips.clone()).unwrap_or_default();
        let me = &mut mobs[a];
        let mut random = me.random.clone();
        let e = ext_mut(me);
        e.gossips.transfer_from(&source, &mut random, 10);
        e.last_gossip_time = now;
        me.random = random;
        ext_mut(&mut mobs[b]).last_gossip_time = now;
    }
    // Surplus food goes to a hungry neighbour (farmers hand it to anyone).
    let farmer = is_farmer(&mobs[a]);
    let wants_more = ext(&mobs[b]).is_none_or(Ext::wants_more_food);
    let excess = ext(&mobs[a]).is_some_and(Ext::has_excess_food);
    let mut thrown = Vec::new();
    if excess
        && (farmer || wants_more)
        && let Some(s) =
            ext_mut(&mut mobs[a]).take_half_stack(|s| food_points(&s.item) > 0, &max_stack)
    {
        thrown.push(s);
    }
    // A farmer's wheat.
    if farmer
        && ext(&mobs[a]).is_some_and(|e| e.count_item("minecraft:wheat") > 32)
        && let Some(s) =
            ext_mut(&mut mobs[a]).take_half_stack(|s| &*s.item == "minecraft:wheat", &max_stack)
    {
        thrown.push(s);
    }
    // Wares the neighbour's profession asks for and ours does not.
    let theirs = requested_items(&mobs[b]);
    let mine = requested_items(&mobs[a]);
    let wanted: Vec<&str> = theirs
        .iter()
        .copied()
        .filter(|i| !mine.contains(i))
        .collect();
    if !wanted.is_empty()
        && let Some(s) =
            ext_mut(&mut mobs[a]).take_half_stack(|s| wanted.contains(&&*s.item), &max_stack)
    {
        thrown.push(s);
    }
    Meeting {
        thrown,
        from: mobs[a].position,
        eye: mobs[a].eye_y(),
        to: mobs[b].position,
        gossiped: ready,
    }
}
/// `Villager.spawnGolemIfNeeded` up to the spawn: villager `i` wants a golem
/// and so do at least `needed` of the villagers whose boxes meet its own grown
/// by 10 blocks. Returns all of those villagers: once the golem stands, they
/// remember it ([`super::villager_brain::golem_detected`]).
pub fn golem_summoners(mobs: &[Mob], i: usize, now: i64, needed: usize) -> Option<Vec<usize>> {
    if !ext(&mobs[i]).is_some_and(|e| e.wants_golem(now)) {
        return None;
    }
    let area = mobs[i]
        .bounds()
        .inflate(horizon_core::geometry::Vec3::new(10.0, 10.0, 10.0));
    let near: Vec<usize> = mobs
        .iter()
        .enumerate()
        .filter(|(_, m)| {
            m.species() == Species::Villager && !m.removed && m.bounds().intersects(area)
        })
        .map(|(j, _)| j)
        .collect();
    let wanting = near
        .iter()
        .filter(|&&j| ext(&mobs[j]).is_some_and(|e| e.wants_golem(now)))
        .take(5)
        .count();
    (wanting >= needed).then_some(near)
}
/// `SpawnUtil.Strategy.LEGACY_IRON_GOLEM`'s refused floors.
fn golem_floor_ok(name: &str) -> bool {
    !matches!(
        name,
        "minecraft:cobweb"
            | "minecraft:cactus"
            | "minecraft:glass_pane"
            | "minecraft:conduit"
            | "minecraft:ice"
            | "minecraft:tnt"
            | "minecraft:glowstone"
            | "minecraft:beacon"
            | "minecraft:sea_lantern"
            | "minecraft:frosted_ice"
            | "minecraft:tinted_glass"
            | "minecraft:glass"
    ) && !name.ends_with("_stained_glass_pane")
        && !name.ends_with("_stained_glass")
        && !name.ends_with("leaves")
}
/// One attempt of `SpawnUtil.trySpawnMob(IRON_GOLEM, ..., 8 across, 6 up and
/// down, LEGACY_IRON_GOLEM)`: a column drawn near `start`, searched down from
/// 6 above for a solid floor (or powder snow) under air or a liquid block.
/// Returns the block the golem would stand in.
fn golem_attempt<L: super::spawn_rules::SpawnLevel>(
    l: &L,
    start: [i32; 3],
    random: &mut impl RandomSource,
) -> Option<[i32; 3]> {
    let dx = random.next_int_bound(17).unwrap_or(8) - 8;
    let dz = random.next_int_bound(17).unwrap_or(8) - 8;
    let (x, z) = (start[0] + dx, start[2] + dz);
    let name = |y: i32| -> &str { &l.facts().get(l.state(x, y, z)).name };
    let mut y = start[1] + 6;
    let mut above = l.state(x, y, z);
    for _ in 0..=12 {
        y -= 1;
        let here = l.state(x, y, z);
        let above_name = &*l.facts().get(above).name;
        // BlockState.liquid(): a water or lava block (not a waterlogged one).
        let open = l.facts().is_air(above)
            || above_name == "minecraft:water"
            || above_name == "minecraft:lava";
        let solid = l.mob_data().state(here).flags & super::data::SOLID != 0
            || name(y) == "minecraft:powder_snow";
        if golem_floor_ok(name(y)) && open && solid {
            return Some([x, y + 1, z]);
        }
        above = here;
    }
    None
}
/// `IronGolem.checkSpawnObstruction`: a floor with a full top face, its feet
/// free whatever fluid is there, and the two blocks above free.
fn golem_fits<L: super::spawn_rules::SpawnLevel>(l: &L, [x, y, z]: [i32; 3]) -> bool {
    use super::spawn_rules::is_valid_empty_spawn;
    // entityCanStandOn: Block.isFaceFull(collision shape, UP).
    let floor = l.mob_data().state(l.state(x, y - 1, z));
    let stands = floor.flags & super::data::STURDY_TOP != 0 && floor.top >= 1.0;
    // isValidEmptySpawnBlock with Fluids.EMPTY: open water is free too.
    let feet = is_valid_empty_spawn(Species::IronGolem, l, x, y, z)
        || &*l.facts().get(l.state(x, y, z)).name == "minecraft:water";
    stands
        && feet
        && is_valid_empty_spawn(Species::IronGolem, l, x, y + 1, z)
        && is_valid_empty_spawn(Species::IronGolem, l, x, y + 2, z)
}
/// `SpawnUtil.trySpawnMob(IRON_GOLEM, MOB_SUMMONED, level, start, 10, 8, 6,
/// LEGACY_IRON_GOLEM, false)`: up to ten columns tried. In each spot found
/// `create` makes the golem (`EntityType.create`: the yaw drawn here, then its
/// `finalizeSpawn` draws, see [`finalize_summoned_golem`]); it is kept only
/// when `IronGolem.checkSpawnObstruction` passes, and discarded otherwise.
pub fn summon_golem<L: super::spawn_rules::SpawnLevel, R: RandomSource, T>(
    l: &L,
    start: [i32; 3],
    random: &mut R,
    mut create: impl FnMut(&mut R, horizon_core::geometry::Vec3, f32) -> T,
) -> Option<T> {
    for _ in 0..10 {
        let Some([x, y, z]) = golem_attempt(l, start, random) else {
            continue;
        };
        // Mth.wrapDegrees(nextFloat() * 360).
        let mut yaw = random.next_float() * 360.0;
        if yaw >= 180.0 {
            yaw -= 360.0;
        }
        let at =
            horizon_core::geometry::Vec3::new(f64::from(x) + 0.5, f64::from(y), f64::from(z) + 0.5);
        let golem = create(random, at, yaw);
        if golem_fits(l, [x, y, z]) {
            return Some(golem);
        }
    }
    None
}
/// `Mob.finalizeSpawn` for a summoned iron golem, from the level's random:
/// the follow range spawn bonus and left-handedness.
pub fn finalize_summoned_golem(m: &mut Mob, random: &mut impl RandomSource) {
    super::finalize::mob_spawn(m, random);
}
/// `Villager.canBreed`: enough food, awake and an adult.
pub fn can_breed(m: &Mob) -> bool {
    m.species() == Species::Villager
        && m.extra.age == 0
        && !sleeping(m)
        && ext(m).map_or(0, |e| e.food_level + e.food_in_inventory()) >= 12
}

/// The saved fields (`FoodLevel`, `Gossips`, `LastGossipDecay`, `Inventory`,
/// `LivingEntity`'s `sleeping_pos` and the sleep and golem memories).
pub fn write_nbt(m: &Mob, map: &mut horizon_core::nbt::Compound) {
    use horizon_core::nbt::Tag;
    if let Some(p) = sleeping_pos(m) {
        map.insert("sleeping_pos".into(), Tag::IntArray(p.to_vec()));
    } else {
        // LivingEntity.addAdditionalSaveData omits an absent modeled position.
        map.remove(&"sleeping_pos".into());
    }
    let Some(e) = ext(m) else { return };
    map.insert(
        "FoodLevel".into(),
        Tag::Byte(e.food_level.clamp(-128, 127) as i8),
    );
    map.insert("Gossips".into(), e.gossips.to_nbt());
    map.insert("LastGossipDecay".into(), Tag::Long(e.last_gossip_decay));
    map.insert(
        "Inventory".into(),
        Tag::List(e.inventory.iter().map(crate::save::item_to_nbt).collect()),
    );
}
/// The memories of `Brain.memories` the villager keeps besides positions.
pub fn write_memories(m: &Mob, memories: &mut Vec<(&'static str, horizon_core::nbt::Tag)>) {
    use super::villager_brain::{Memories, NEVER, Slot};
    use horizon_core::nbt::Tag;
    fn push<T>(
        out: &mut Vec<(&'static str, Tag)>,
        key: &'static str,
        slot: &Slot<T>,
        encode: impl FnOnce(&T) -> Tag,
    ) {
        if let Some(value) = slot.get() {
            let mut fields = vec![("value", encode(value))];
            if slot.ttl() != NEVER {
                fields.push(("ttl", Tag::Long(slot.ttl())));
            }
            out.push((key, Tag::compound(fields)));
        }
    }
    let Some(e) = ext(m) else { return };
    let fallback = Memories::default();
    let mm = e
        .brain
        .as_ref()
        .map(|b| &b.mem)
        .or(e.saved_memories.as_deref())
        .unwrap_or(&fallback);
    // The three established position fields are written by entity_nbt; replace
    // them only when the live brain has a value (and therefore a possible TTL).
    for (key, slot) in [
        ("minecraft:home", &mm.home),
        ("minecraft:job_site", &mm.job_site),
        ("minecraft:meeting_point", &mm.meeting_point),
        ("minecraft:potential_job_site", &mm.potential_job_site),
    ] {
        if slot.present() {
            memories.retain(|(k, _)| *k != key);
            push(memories, key, slot, |p| {
                Tag::compound([
                    ("dimension", Tag::String("minecraft:overworld".into())),
                    ("pos", Tag::IntArray(p.to_vec())),
                ])
            });
        }
    }
    push(
        memories,
        "minecraft:golem_detected_recently",
        &mm.golem_detected_recently,
        |v| Tag::Byte(i8::from(*v)),
    );
    if mm.last_slept.present() {
        push(memories, "minecraft:last_slept", &mm.last_slept, |v| {
            Tag::Long(*v)
        });
    } else if e.brain.is_none()
        && e.saved_memories.is_none()
        && let Some(t) = e.last_slept
    {
        memories.push((
            "minecraft:last_slept",
            Tag::compound([("value", Tag::Long(t))]),
        ));
    }
    push(memories, "minecraft:last_woken", &mm.last_woken, |v| {
        Tag::Long(*v)
    });
}

pub fn read_nbt(m: &mut Mob, tag: &horizon_core::nbt::Tag) {
    use horizon_core::nbt::Tag;
    fn int(t: Option<&Tag>) -> Option<i64> {
        match t {
            Some(Tag::Int(v)) => Some(i64::from(*v)),
            Some(Tag::Byte(v)) => Some(i64::from(*v)),
            Some(Tag::Short(v)) => Some(i64::from(*v)),
            Some(Tag::Long(v)) => Some(*v),
            _ => None,
        }
    }
    let memories = tag.get("Brain").and_then(|b| b.get("memories"));
    let mut saved = super::villager_brain::Memories::default();
    fn read<T>(
        memories: Option<&Tag>,
        key: &str,
        slot: &mut super::villager_brain::Slot<T>,
        decode: impl FnOnce(&Tag) -> Option<T>,
    ) {
        if let Some(entry) = memories.and_then(|m| m.get(key))
            && let Some(value) = entry.get("value").and_then(decode)
        {
            // `ExpirableValue.codec`: a lenient optional `Codec.LONG`.
            match int(entry.get("ttl")) {
                Some(ttl) => slot.set_ttl(value, ttl),
                None => slot.set(value),
            }
        }
    }
    for (key, slot) in [
        ("minecraft:home", &mut saved.home),
        ("minecraft:job_site", &mut saved.job_site),
        ("minecraft:meeting_point", &mut saved.meeting_point),
        (
            "minecraft:potential_job_site",
            &mut saved.potential_job_site,
        ),
    ] {
        read(memories, key, slot, |v| match v.get("pos") {
            Some(Tag::IntArray(p)) if p.len() == 3 => Some([p[0], p[1], p[2]]),
            _ => None,
        });
    }
    read(
        memories,
        "minecraft:golem_detected_recently",
        &mut saved.golem_detected_recently,
        |v| int(Some(v)).map(|v| v != 0),
    );
    read(
        memories,
        "minecraft:last_slept",
        &mut saved.last_slept,
        |v| int(Some(v)),
    );
    read(
        memories,
        "minecraft:last_woken",
        &mut saved.last_woken,
        |v| int(Some(v)),
    );
    let e = ext_mut(m);
    e.food_level = int(tag.get("FoodLevel")).unwrap_or(0) as i32;
    e.gossips = tag
        .get("Gossips")
        .map(crate::gossip::Gossips::from_nbt)
        .unwrap_or_default();
    e.last_gossip_decay = int(tag.get("LastGossipDecay")).unwrap_or(0);
    e.last_slept = saved.last_slept.value();
    e.saved_memories = Some(Box::new(saved));
    // LivingEntity.readAdditionalSaveData: asleep in the bed again (the
    // pose; `ai_step` turns it the way the bed faces, or wakes it when the
    // bed is gone, as `baseTick`'s first tick does).
    e.sleeping_pos = match tag.get("sleeping_pos") {
        Some(Tag::IntArray(a)) if a.len() == 3 => Some([a[0], a[1], a[2]]),
        _ => None,
    };
    let asleep = e.sleeping_pos.is_some();
    // InventoryCarrier.readInventoryFromTag -> SimpleContainer.fromItemList.
    if let Some(Tag::List(items)) = tag.get("Inventory") {
        let inventory = load_container(m, items, INVENTORY_SLOTS);
        ext_mut(m).inventory = inventory;
    }
    if asleep {
        m.extra.ints[1] = bed_facing_code(None);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // 26.3 VillagerProfession.bootstrap, PoiTypes.bootstrap and TradeSets.
    #[test]
    fn vanilla_profession_table_and_job_sites() {
        let cases = [
            ("none", &[][..]),
            ("armorer", &["blast_furnace"][..]),
            ("butcher", &["smoker"][..]),
            ("cartographer", &["cartography_table"][..]),
            ("cleric", &["brewing_stand"][..]),
            ("farmer", &["composter"][..]),
            ("fisherman", &["barrel"][..]),
            ("fletcher", &["fletching_table"][..]),
            (
                "leatherworker",
                &[
                    "cauldron",
                    "water_cauldron",
                    "lava_cauldron",
                    "powder_snow_cauldron",
                ][..],
            ),
            ("librarian", &["lectern"][..]),
            ("mason", &["stonecutter"][..]),
            ("nitwit", &[][..]),
            ("shepherd", &["loom"][..]),
            ("toolsmith", &["smithing_table"][..]),
            ("weaponsmith", &["grindstone"][..]),
        ];
        for (index, (name, sites)) in cases.iter().enumerate() {
            let index = index as u8;
            assert_eq!(profession(index).id, *name);
            assert_eq!(profession_index(name), Some(index));
            assert_eq!(profession(index).render_index, index);
            for site in *sites {
                let state = horizon_world::chunk::BlockState {
                    name: format!("minecraft:{site}"),
                    properties: Default::default(),
                };
                let poi = horizon_world::poi::saved_poi(&state).unwrap();
                assert_eq!(poi.id(), format!("minecraft:{name}"));
                assert_eq!(profession_table().by_poi(poi), Some(index));
                assert!(profession_table().held(index, poi));
                assert!(profession_table().acquirable(index, poi));
            }
            for level in 1..=5 {
                assert_eq!(
                    crate::merchant::Trades::set_for(name, level),
                    format!("minecraft:{name}/level_{level}")
                );
            }
        }
        assert_eq!(profession(255).id, "none");
        assert_eq!(profession_index("other:farmer"), None);
        assert_eq!(
            crate::merchant::Trades::set_for("other:farmer", 2),
            "minecraft:other:farmer/level_2"
        );
    }

    /// Added after the H138 baseline: `add_item` delegates to
    /// `add_to_container` with the eight villager slots, with the same
    /// inventories and remainders in the same order.
    #[test]
    fn add_item_is_add_to_container_with_eight_slots() {
        let st = |id: &str, n: u32| ItemStack::new(id, n);
        let sequences: [&[(&str, u32, u32)]; 3] = [
            &[
                ("minecraft:stone", 40, 64),
                ("minecraft:stone", 40, 64),
                ("minecraft:dirt", 1, 64),
            ],
            &[
                ("minecraft:ender_pearl", 10, 16),
                ("minecraft:ender_pearl", 10, 16),
            ],
            &[("minecraft:stone", 64, 64); 10],
        ];
        for seq in sequences {
            let mut ext = Ext::default();
            let mut vec = Vec::new();
            for &(id, n, max) in seq {
                let a = ext
                    .add_item(st(id, n), max)
                    .map(|s| (s.item.to_string(), s.count));
                let b = add_to_container(&mut vec, st(id, n), max, INVENTORY_SLOTS)
                    .map(|s| (s.item.to_string(), s.count));
                assert_eq!(a, b);
                let counts = |v: &[ItemStack]| {
                    v.iter()
                        .map(|s| (s.item.to_string(), s.count))
                        .collect::<Vec<_>>()
                };
                assert_eq!(counts(&ext.inventory), counts(&vec));
            }
        }
    }

    /// Added after the H138 baseline: eight kinds fill the eight slots; a
    /// later stack of a kind already held still fills its stack, and a
    /// ninth kind does not fit (fromItemList drops it).
    #[test]
    fn a_later_stack_still_merges_into_a_full_set_of_slots() {
        let kinds = [
            "stone",
            "dirt",
            "cobblestone",
            "oak_planks",
            "sand",
            "gravel",
            "oak_log",
            "glass",
        ];
        let mut vec = Vec::new();
        for k in kinds {
            assert!(
                add_to_container(
                    &mut vec,
                    ItemStack::new(&format!("minecraft:{k}"), 1),
                    64,
                    8
                )
                .is_none()
            );
        }
        assert!(add_to_container(&mut vec, ItemStack::new("minecraft:stone", 5), 64, 8).is_none());
        assert_eq!(vec.len(), 8);
        assert_eq!((vec[0].item.as_ref(), vec[0].count), ("minecraft:stone", 6));
        let rest = add_to_container(&mut vec, ItemStack::new("minecraft:clay", 1), 64, 8);
        assert_eq!(rest.map(|s| s.count), Some(1));
        assert_eq!(vec.len(), 8);
    }

    fn memory_fixture() -> Mob {
        let mut m = villager();
        super::super::villager_brain::init(&mut m, 0, 0, 1);
        let mm = &mut ext_mut(&mut m).brain.as_mut().unwrap().mem;
        mm.golem_detected_recently.set_ttl(true, 42);
        mm.last_slept.set_ttl(101, 17);
        mm.last_woken.set(202);
        mm.last_worked_at_poi.set_ttl(303, 7);
        mm.potential_job_site.set_ttl([4, 5, 6], 9);
        m
    }

    #[test]
    fn villager_memory_nbt_shape() {
        use horizon_core::nbt::Tag;
        let m = memory_fixture();
        let mut entries = Vec::new();
        write_memories(&m, &mut entries);
        let actual = Tag::compound(entries);
        let expected = Tag::compound([
            (
                "minecraft:golem_detected_recently",
                Tag::compound([("value", Tag::Byte(1)), ("ttl", Tag::Long(42))]),
            ),
            (
                "minecraft:last_slept",
                Tag::compound([("value", Tag::Long(101)), ("ttl", Tag::Long(17))]),
            ),
            (
                "minecraft:last_woken",
                Tag::compound([("value", Tag::Long(202))]),
            ),
            (
                "minecraft:potential_job_site",
                Tag::compound([
                    (
                        "value",
                        Tag::compound([
                            ("dimension", Tag::String("minecraft:overworld".into())),
                            ("pos", Tag::IntArray(vec![4, 5, 6])),
                        ]),
                    ),
                    ("ttl", Tag::Long(9)),
                ]),
            ),
        ]);
        assert_eq!(actual, expected);
    }

    #[test]
    fn villager_memory_round_trip() {
        use horizon_core::nbt::Tag;
        let m = memory_fixture();
        let mut entries = Vec::new();
        write_memories(&m, &mut entries);
        entries.push((
            "minecraft:last_worked_at_poi",
            Tag::compound([("value", Tag::Long(303)), ("ttl", Tag::Long(7))]),
        ));
        let tag = Tag::compound([(
            "Brain",
            Tag::compound([("memories", Tag::compound(entries))]),
        )]);
        let mut loaded = villager();
        read_nbt(&mut loaded, &tag);
        super::super::villager_brain::init(&mut loaded, 500, 0, 1);
        let mm = &mut ext_mut(&mut loaded).brain.as_mut().unwrap().mem;
        assert_eq!(
            (
                mm.golem_detected_recently.value(),
                mm.golem_detected_recently.ttl()
            ),
            (Some(true), 42)
        );
        assert_eq!(
            (mm.last_slept.value(), mm.last_slept.ttl()),
            (Some(101), 17)
        );
        assert_eq!(
            (mm.last_woken.value(), mm.last_woken.ttl()),
            (Some(202), i64::MAX)
        );
        assert_eq!(
            (mm.last_worked_at_poi.value(), mm.last_worked_at_poi.ttl()),
            (None, i64::MAX)
        );
        assert_eq!(
            (mm.potential_job_site.value(), mm.potential_job_site.ttl()),
            (Some([4, 5, 6]), 9)
        );
        for _ in 0..42 {
            mm.golem_detected_recently.tick();
        }
        assert!(mm.golem_detected_recently.present());
        mm.golem_detected_recently.tick();
        assert!(!mm.golem_detected_recently.present());
    }

    fn villager() -> Mob {
        use crate::mobs::{Anim, Brain, Flags, MobType, Part, Species};
        use std::sync::Arc;
        let kind = Arc::new(MobType {
            id: "minecraft:villager".into(),
            species: Species::Villager,
            width: 0.6,
            height: 1.95,
            eye_height: 1.62,
            category: "misc".into(),
            max_health: 20.0,
            speed: 0.5,
            flying_speed: 0.02,
            attack_damage: 0.0,
            attack_knockback: 0.0,
            follow_range: 48.0,
            step_height: 0.6,
            armor: 0.0,
            armor_toughness: 0.0,
            knockback_resistance: 0.0,
            jump_strength: 0.42,
            attributes: Arc::default(),
            item_stack_limits: Default::default(),
            gravity: 0.08,
            safe_fall_distance: 3.0,
            fall_damage_multiplier: 1.0,
            water_efficiency: 0.0,
            water_slowdown: 0.8,
            air_speed: 0.02,
            baby_scale: 0.5,
            head_rot_speed: 10.0,
            max_head_x_rot: 40.0,
            max_head_y_rot: 75.0,
            ambient_interval: 80,
            flags: Flags::default(),
            model: Arc::new(Part::parse("root", &serde_json::json!({}))),
            layers: Default::default(),
            texture: String::new(),
            brain: Brain::Passive,
            anim: Anim::Villager,
            sounds: [""; 3],
            step_sound: None,
            food: Arc::default(),
            tempt: Arc::default(),
            passenger_attachments: Vec::new(),
        });
        Mob::new(1, kind, horizon_core::geometry::Vec3::ZERO, 0.0)
    }
    #[test]
    fn waking_faces_the_bed_and_resets_pitch_without_moving_the_chosen_position() {
        let mut m = villager();
        m.yaw = -25.0;
        m.head_pitch = 23.0;
        let stand = horizon_core::geometry::Vec3::new(3.5, 200.0, 6.5);
        set_wake_pose(&mut m, [2, 200, 6], stand);
        // Fresh official 26.3 occupied-bed interaction.
        assert_eq!(m.yaw, 89.99999);
        assert_eq!(m.head_pitch, 0.0);
        assert_eq!(m.position, stand);
    }
    /// A sleeper's box is 0.2 high, but `LivingEntityRenderer` moves it
    /// toward the foot of the bed by its standing eye height, so its head
    /// lies on the pillow.
    #[test]
    fn a_sleeper_lies_by_its_standing_eye_height() {
        let mut m = villager();
        m.extra.ints[1] = bed_facing_code(Some("east"));
        assert!(sleeping(&m));
        assert_eq!(m.eye_height(), f64::from(0.2_f32));
        assert_eq!(m.awake_dims().2, f64::from(1.62_f32));
    }
    /// `LivingEntity.add/readAdditionalSaveData`: a sleeper is saved with
    /// its bed (`sleeping_pos`) and loads asleep in it.
    #[test]
    fn a_sleeper_is_saved_asleep_in_its_bed() {
        let mut m = villager();
        m.extra.ints[1] = bed_facing_code(Some("north"));
        ext_mut(&mut m).sleeping_pos = Some([3, 64, -7]);
        let mut map = horizon_core::nbt::Compound::new();
        write_nbt(&m, &mut map);
        let mut loaded = villager();
        read_nbt(&mut loaded, &horizon_core::nbt::Tag::Compound(map));
        assert!(sleeping(&loaded));
        assert_eq!(sleeping_pos(&loaded), Some([3, 64, -7]));
        let mut awake = villager();
        let mut map = horizon_core::nbt::Compound::new();
        write_nbt(&awake, &mut map);
        assert!(!map.contains_key(&"sleeping_pos".into()));
        read_nbt(&mut awake, &horizon_core::nbt::Tag::Compound(map));
        assert!(!sleeping(&awake));
    }
    #[test]
    fn saved_sleeping_position_follows_live_state_over_stale_input() {
        use horizon_core::nbt::Tag;
        for asleep in [false, true] {
            let mut m = villager();
            if asleep {
                m.extra.ints[1] = bed_facing_code(Some("north"));
                ext_mut(&mut m).sleeping_pos = Some([3, 64, -7]);
            }
            let expected = asleep.then_some(Tag::IntArray(vec![3, 64, -7]));
            for stale in [false, true] {
                let mut map = horizon_core::nbt::Compound::new();
                map.insert("h232_control".into(), Tag::Int(42));
                if stale {
                    map.insert("sleeping_pos".into(), Tag::IntArray(vec![9, 90, 9]));
                }
                write_nbt(&m, &mut map);
                assert_eq!(map.get(&"sleeping_pos".into()), expected.as_ref());
                assert_eq!(map.get(&"h232_control".into()), Some(&Tag::Int(42)));
            }
            let saved = crate::entity_nbt::mob_to_nbt(&m, [0; 4], None, None, |_| None);
            assert_eq!(saved.get("sleeping_pos"), expected.as_ref());
        }
    }
    /// `Villager.setUnhappy` -> `Mob.makeSound(VILLAGER_NO)` plays with
    /// `LivingEntity.getVoicePitch`: a baby is pitched about 1.5, an adult 1.0.
    #[test]
    fn the_unhappy_sound_uses_the_voice_pitch() {
        let sound_pitch = |age: i32| {
            let mut m = villager();
            m.extra.age = age;
            let mut events = Vec::new();
            set_unhappy(&mut m, &mut events);
            match events[0] {
                MobEvent::Sound(_, _, _, pitch) => pitch,
                _ => panic!("expected a sound"),
            }
        };
        assert!((0.8..=1.2).contains(&sound_pitch(0)));
        assert!((1.3..=1.7).contains(&sound_pitch(-24000)));
    }
    #[test]
    fn a_new_profession_rolls_new_offers() {
        let mut m = villager();
        set_profession(&mut m, 1);
        // Offers made for the first profession.
        m.extra.trade.get_or_insert_default().unset = false;
        // The same profession keeps them.
        set_profession(&mut m, 1);
        assert!(!m.extra.trade.as_ref().unwrap().unset);
        // A new one forgets them (offers = null), so the next getOffers
        // (ensure_offers) rolls the new profession's trades.
        set_profession(&mut m, 2);
        let t = m.extra.trade.as_ref().unwrap();
        assert!(t.offers.is_empty());
        assert!(t.unset);
        assert_eq!(m.extra.profession.index().unwrap_or(0), 2);
    }
    /// The reported sequence: a villager works at a bench, the bench is
    /// destroyed (its job site is gone, so `ResetProfession` makes it
    /// unemployed) and it takes another bench's job. The new profession's
    /// trades are offered again.
    ///
    /// `Villager.setVillagerData` drops the offers (`offers = null`) when the
    /// profession changes, so `AbstractVillager.getOffers` rolls the new
    /// profession's trade set the next time the offers are asked for. A
    /// villager that keeps its old offers marked as made never trades again:
    /// it shakes its head instead of opening the trading menu.
    #[test]
    fn a_villager_that_loses_its_job_site_offers_its_new_profession_trades() {
        let mut m = villager();
        // The composter's job: the villager is a farmer.
        set_profession(&mut m, 5);
        assert_eq!(m.extra.profession.index().unwrap_or(0), 5);
        // Its trades were made, so the offers are there.
        let trade = m.extra.trade.get_or_insert_default();
        trade.unset = false;
        trade.offers = vec![crate::merchant::MerchantOffer {
            base_cost_a: crate::merchant::ItemCost {
                stack: ItemStack::new("minecraft:wheat", 20),
            },
            cost_b: None,
            result: ItemStack::new("minecraft:emerald", 1),
            uses: 0,
            max_uses: 16,
            reward_exp: true,
            special_price_diff: 0,
            demand: 0,
            price_multiplier: 0.0,
            xp: 1,
        }];
        // The work bench is destroyed: the job site is gone, so the villager
        // is unemployed and its offers are dropped (`offers = null`).
        set_profession(&mut m, NONE);
        let t = m.extra.trade.as_ref().unwrap();
        assert!(t.offers.is_empty());
        assert!(t.unset);
        // It takes the smithing table's job. The new profession's trades are
        // rolled by the next `getOffers` (ensure_offers).
        set_profession(&mut m, 13);
        let t = m.extra.trade.as_ref().unwrap();
        assert!(t.offers.is_empty());
        assert!(t.unset);
        assert_eq!(m.extra.profession.index().unwrap_or(0), 13);
    }

    fn stack(item: &str, count: u32) -> ItemStack {
        ItemStack::new(item, count)
    }
    #[test]
    fn eating_fills_the_food_level_then_digests() {
        let mut e = Ext {
            inventory: vec![stack("minecraft:bread", 3), stack("minecraft:carrot", 5)],
            ..Default::default()
        };
        assert_eq!(e.food_in_inventory(), 17);
        // Hungry below 12: three breads fill it exactly, then 12 digest away.
        e.eat_and_digest();
        assert_eq!(e.food_level, 0);
        assert_eq!(e.inventory.len(), 1);
        assert_eq!(e.inventory[0].count, 5);
        // Five carrots are not enough to be full again, and are all eaten.
        e.eat_and_digest();
        assert_eq!(e.food_level, 5 - 12);
        assert!(e.inventory.is_empty());
    }
    #[test]
    fn willingness_to_breed_needs_twelve_food_points() {
        let mut e = Ext::default();
        assert!(e.wants_more_food() && !e.has_excess_food());
        e.inventory.push(stack("minecraft:bread", 6));
        assert!(e.has_excess_food() && !e.wants_more_food());
        e.food_level = -5;
        assert_eq!(e.food_level + e.food_in_inventory(), 19);
    }
    #[test]
    fn the_inventory_has_eight_stacking_slots() {
        let mut e = Ext::default();
        assert!(e.add_item(stack("minecraft:bread", 100), 64).is_none());
        assert_eq!(e.inventory.len(), 2);
        assert_eq!(e.inventory[0].count, 64);
        for i in 0..6 {
            assert!(
                e.add_item(stack(&format!("minecraft:item_{i}"), 1), 64)
                    .is_none()
            );
        }
        assert_eq!(e.inventory.len(), 8);
        // Full: another kind is refused, the same kind tops up the stack.
        assert!(!e.can_add(&stack("minecraft:stick", 1), 64));
        let left = e.add_item(stack("minecraft:bread", 40), 64).unwrap();
        assert_eq!(left.count, 40 - 28);
    }
    #[test]
    fn half_stacks_are_thrown() {
        let mut e = Ext {
            inventory: vec![
                stack("minecraft:bread", 10),
                stack("minecraft:wheat", 50),
                stack("minecraft:wheat", 20),
            ],
            ..Default::default()
        };
        let max = |_: &str| 64;
        // Bread is under half a stack and under 24: nothing.
        assert!(
            e.take_half_stack(|s| &*s.item == "minecraft:bread", max)
                .is_none()
        );
        // 50 wheat is over half a stack: 25 go.
        let t = e
            .take_half_stack(|s| &*s.item == "minecraft:wheat", max)
            .unwrap();
        assert_eq!(t.count, 25);
        assert_eq!(e.count_item("minecraft:wheat"), 25 + 20);
    }
    #[test]
    fn golems_need_sleep_and_no_golem_nearby() {
        let mut e = Ext::default();
        assert!(!e.wants_golem(100));
        e.last_slept = Some(0);
        assert!(e.wants_golem(23_999));
        assert!(!e.wants_golem(24_000));
        e.last_slept = Some(1000);
        e.golem_until = 2000 + 599;
        assert!(!e.wants_golem(2500));
        assert!(e.wants_golem(2700));
    }
    #[test]
    fn gossip_decays_once_a_day_and_heard_gossip_waits() {
        let player = [1, 2, 3, 4];
        let mut e = Ext::default();
        e.gossips
            .add(player, crate::gossip::GossipType::MajorNegative, 25);
        e.maybe_decay(100);
        assert_eq!(e.last_gossip_decay, 100);
        e.maybe_decay(24_099);
        assert_eq!(
            e.gossips
                .get(player, crate::gossip::GossipType::MajorNegative),
            25
        );
        e.maybe_decay(24_100);
        assert_eq!(
            e.gossips
                .get(player, crate::gossip::GossipType::MajorNegative),
            15
        );
        e.last_gossip_time = 5000;
        assert!(!e.can_gossip(5100));
        assert!(e.can_gossip(6200));
        assert!(e.can_gossip(4000));
    }
    #[test]
    fn villager_food_values() {
        assert_eq!(food_points("minecraft:bread"), 4);
        assert_eq!(food_points("minecraft:beetroot"), 1);
        assert_eq!(food_points("minecraft:apple"), 0);
    }
}
