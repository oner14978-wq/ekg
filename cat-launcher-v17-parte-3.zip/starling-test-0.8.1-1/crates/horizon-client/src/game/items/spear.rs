//! Spears (`KineticWeapon`): holding the use button charges the spear, and
//! from `delay_ticks` on every living entity along the view that the
//! player's speed allows is stabbed: the damage grows with the speed
//! relative to the target, the knockback and the dismount need the
//! attacker's own speed, and each condition runs out after its time
//! (`Item.use`, `ItemStack.onUseTick`, `KineticWeapon.damageEntities`,
//! `Player.stabAttack`). The hit's feedback (`onKineticHit`) reaches the
//! players around as entity event 2. A left click jabs instead
//! (`PiercingWeapon.attack`), which Lunge turns into a dash.
use super::{Game, view_vector};
pub(super) use horizon_client::spear::hits_in_reach;
use horizon_client::{
    attack_strength::delay,
    collisions::SceneCollisions,
    first_person::Hand,
    items::ItemStack,
    mobs::Damage,
    spear::{HIT_FEEDBACK_TICKS, Kinetic, REACH},
};
use horizon_core::{
    geometry::{Aabb, Vec3, traverse_blocks},
    position::BlockPos,
};

/// The key of this window's own player in `Game::kinetic_feedback`.
pub(super) const OWN: i32 = i32::MIN;

/// What a stab reaches along the view: a mob (its index in `mobs`) or
/// another player (its index in `stab_players`).
#[derive(Clone, Copy)]
enum Target {
    Mob(usize),
    Player(usize),
}

impl Game<'_> {
    /// `Item.use` of a kinetic weapon: `startUsingItem` with a new
    /// `recentKineticEnemies`, and `KineticWeapon.makeSound` at the user.
    pub(super) fn use_spear(&mut self, stack: &ItemStack) -> bool {
        let Some(kinetic) = Kinetic::of(&stack.item) else {
            return false;
        };
        if self.start_using_item() {
            let actor = self.lan_acting;
            self.stabbed.retain(|(who, _), _| *who != actor);
            if let Some(p) = &self.player {
                let at = [p.position.x, p.position.y, p.position.z];
                self.audio.play(kinetic.sound, Some(at), 1.0, 1.0);
            }
        }
        true
    }

    /// `ServerPlayer.getKnownMovement` of the acting player: what they moved
    /// in the last tick. A guest's comes with their moves. A rider's is its
    /// mount's move (`getKnownSpeed`: the vehicle's, or the move the driver's
    /// client sent for it), so a charge on horseback carries the horse's speed.
    pub(super) fn known_player_movement(&self) -> Vec3 {
        if let Some(i) = self
            .riding
            .and_then(|v| self.mobs.iter().position(|m| m.id == v))
        {
            return self.mob_speed(i).scale(1.0 / 20.0);
        }
        if self.lan_acting.is_some() {
            return self.known_movement;
        }
        self.player
            .as_ref()
            .map_or(Vec3::ZERO, |p| p.position.subtract(self.previous_position))
    }

    /// `Entity.getKnownSpeed` of the mob at `index`, per second: its root
    /// vehicle's (`KineticWeapon.getMotion`).
    fn mob_speed(&self, index: usize) -> Vec3 {
        let mut mob = &self.mobs[index];
        while let Some(vehicle) = mob
            .extra
            .mount
            .and_then(|v| self.mobs.iter().find(|m| m.id == v))
        {
            mob = vehicle;
        }
        mob.position.subtract(mob.previous).scale(20.0)
    }

    /// `Level.clip` with COLLIDER shapes and no fluids: where the segment
    /// first meets a block, if it does (tall grass lets a stab through).
    fn clip_collider(&self, from: Vec3, to: Vec3) -> Option<Vec3> {
        let mut scene = SceneCollisions {
            world: &self.world,
            binding: self.collision,
            subject: None,
        };
        traverse_blocks(from, to, 512, |p: BlockPos| {
            let state = self.world.block(p.x, p.y, p.z);
            if self.res.facts().is_air(state) {
                return None;
            }
            let shape = self
                .collision
                .collision_shape(&mut scene, state, [p.x, p.y, p.z])
                .ok()?;
            shape.clip(from, to, p).map(|hit| hit.location)
        })
        .ok()
        .flatten()
    }

    /// The boxes of the mobs a spear can hit: alive, and not the vehicle
    /// ridden (`PiercingWeapon.canHitEntity`), with their index.
    pub(super) fn hittable_mob_boxes(&self) -> Vec<(usize, Aabb)> {
        (self.mobs.iter().enumerate())
            .filter(|(_, m)| m.alive() && !m.removed && self.riding != Some(m.id))
            .map(|(i, m)| (i, m.bounds()))
            .collect()
    }

    /// `ProjectileUtil.getHitEntitiesAlong` with the spear's `AttackRange`:
    /// the mobs and the other players along the view, nearest first.
    fn stab_targets(&self, eye: Vec3, look: Vec3, movement: Vec3) -> Vec<Target> {
        // AttackRange.effectiveMinRange and effectiveMaxRange for a player.
        let (min, max) = if self.creative {
            (REACH.min_creative, REACH.max_creative)
        } else {
            (REACH.min, REACH.max)
        };
        let reach = (min, max, REACH.hitbox_margin);
        let clip = |from, to| self.clip_collider(from, to);
        let mobs = self.mobs.len();
        let mut boxes = self.hittable_mob_boxes();
        boxes.extend((self.stab_players.iter().enumerate()).map(|(k, p)| (mobs + k, p.bounds)));
        hits_in_reach(&boxes, eye, look, movement, reach, clip)
            .into_iter()
            .map(|(i, _)| {
                if i < mobs {
                    Target::Mob(i)
                } else {
                    Target::Player(i - mobs)
                }
            })
            .collect()
    }

    /// `KineticWeapon.damageEntities`: one tick of the spear in use, `ticks`
    /// ticks into the use.
    pub(super) fn spear_tick(&mut self, stack: &ItemStack, ticks: u32) {
        let Some(kinetic) = Kinetic::of(&stack.item) else {
            return;
        };
        let used = ticks as i32 - kinetic.delay_ticks;
        let (Some(eye), Some(_)) = (
            self.eye_position(),
            self.player.as_ref().map(|p| p.position),
        ) else {
            return;
        };
        if used < 0 || self.spectator() {
            return;
        }
        let eye = Vec3::new(eye[0], eye[1], eye[2]);
        let look = view_vector(self.yaw, self.pitch);
        let look = Vec3::new(look[0], look[1], look[2]);
        let movement = self.known_player_movement();
        let attacker_speed = look.dot(movement.scale(20.0));
        let now = self.world.game_time;
        let actor = self.lan_acting;
        let mut affected = false;
        let mut on_players = Vec::new();
        for target in self.stab_targets(eye, look, movement) {
            let (entity, target_motion) = match target {
                Target::Mob(i) => (self.mobs[i].id, self.mob_speed(i)),
                Target::Player(k) => {
                    let p = &self.stab_players[k];
                    (p.entity_id as u32, p.movement.scale(20.0))
                }
            };
            let key = (actor, entity);
            let recent = self
                .stabbed
                .get(&key)
                .is_some_and(|&t| now - t < i64::from(kinetic.contact_cooldown_ticks));
            if recent {
                continue;
            }
            self.stabbed.insert(key, now);
            let target_speed = look.dot(target_motion);
            let relative = (attacker_speed - target_speed).max(0.0);
            // An entity factor of 1 for a player.
            let dismounts = kinetic.dismount.test(used, attacker_speed, relative, 1.0);
            let pushes = kinetic.knockback.test(used, attacker_speed, relative, 1.0);
            let damages = kinetic.damage.test(used, attacker_speed, relative, 1.0);
            if dismounts || pushes || damages {
                // The attack damage attribute's base value (1) and the speed.
                let amount = 1.0 + (relative * f64::from(kinetic.damage_multiplier)).floor() as f32;
                match target {
                    Target::Mob(i) => {
                        affected |= self.stab_mob(i, amount, damages, pushes, dismounts)
                    }
                    Target::Player(k) => on_players
                        .extend(self.queue_player_stab(k, amount, damages, pushes, dismounts)),
                }
            }
        }
        if affected {
            self.spear_hit_feedback(&kinetic);
        }
        self.keep_player_stabs(kinetic, true, affected, on_players);
    }

    /// What follows a charge tick that affected an entity:
    /// `Level.broadcastEntityEvent(player, 2)`, felt by the player too, and
    /// SPEAR_MOBS_TRIGGER with the living entities stabbed in this use.
    pub(super) fn spear_hit_feedback(&mut self, kinetic: &Kinetic) {
        let Some(feet) = self.player.as_ref().map(|p| p.position) else {
            return;
        };
        let actor = self.lan_acting;
        if self.audio.capture.is_some() {
            self.lan_kinetic_hits.push(actor);
        }
        let who = actor.map_or(OWN, |conn| conn as i32);
        self.kinetic_hit_feedback(who, kinetic, [feet.x, feet.y, feet.z]);
        let stabbed = self.stabbed.keys().filter(|(who, _)| *who == actor).count();
        self.trigger_spear_mobs(stabbed);
    }

    /// `Player.stabAttack` on the mob at `index`: whether it was affected.
    fn stab_mob(
        &mut self,
        index: usize,
        base_damage: f32,
        deals_damage: bool,
        deals_knockback: bool,
        dismounts: bool,
    ) -> bool {
        let kind = format!(
            "minecraft:{}",
            self.mobs[index].kind.id.trim_start_matches("minecraft:")
        );
        let id = self.mobs[index].id;
        let Some(p) = self.player.as_ref() else {
            return false;
        };
        let attack = self.attack_of(p.entity_id);
        let from = [p.position.x, p.position.y, p.position.z];
        // The enchantments' share, scaled by the attack strength unless the
        // weapon is in use.
        let magic_boost = self.enchant_damage_bonus(&kind, Some(id));
        let (base_damage, magic_boost) = if self.using.is_none() {
            let scale = self.attack_strength_scale();
            (
                base_damage * (0.2 + scale * scale * 0.8),
                magic_boost * scale,
            )
        } else {
            (base_damage, magic_boost)
        };
        let total = if deals_damage {
            base_damage + magic_boost
        } else {
            0.0
        };
        let old_health = self.mobs[index].health;
        let hurt = deals_damage && self.hurt_by_player(index, total, Damage::spear(from));
        if hurt && old_health > 0.0 && !self.mobs[index].alive() {
            self.native_kill_event(index);
        }
        // causeExtraKnockback: a push of 0.4, then the weapon's Knockback.
        if deals_knockback {
            let (xd, zd) = self.extra_knockback_direction();
            let source = Damage::spear(from);
            let level = crate::game::entity::damage_level_of!(self, &attack);
            self.mobs[index].knockback_full(level, 0.4, xd, zd, &source, total, false);
            let (strength, _) = self.extra_knockback(&kind, 0.0);
            if strength > 0.0 {
                let level = crate::game::entity::damage_level_of!(self, &attack);
                self.mobs[index].knockback_full(
                    level,
                    f64::from(strength),
                    xd,
                    zd,
                    &source,
                    total,
                    true,
                );
            }
            // ...and the attacker stops sprinting.
            self.stop_sprint_after_extra_knockback();
        }
        let dismounted = dismounts && self.mobs[index].extra.mount.is_some();
        if dismounted {
            self.dismount_mob(id);
        }
        if !hurt && !deals_knockback && !dismounted {
            return false;
        }
        let mob = &self.mobs[index];
        let (feet, width, height) = (
            [mob.position.x, mob.position.y, mob.position.z],
            mob.kind.width,
            mob.kind.height,
        );
        // attackVisualEffects: no attack sound, the enchantments' magic crit.
        if magic_boost > 0.0 {
            self.critical_hit(self.lan_acting, id as i32, feet, width, height, true);
        }
        self.combat.last_hurt_mob = Some((id, self.world.game_time));
        // itemAttackInteraction: hurtEnemy (statistic, wear), and the
        // post-attack enchantments when the target was hurt.
        if let Some(stack) = self.held().cloned() {
            self.award_stat("used", &stack.item, 1);
            if hurt {
                self.post_attack(index);
            }
            self.weapon_wear(&stack);
        }
        // damageStatsAndHearts.
        let actual = old_health - self.mobs[index].health;
        self.damage_stats_and_hearts(actual, feet, height);
        if hurt {
            self.remember_mob_player_credit(id);
        }
        if let Some(p) = self.player.as_mut()
            && !self.creative
        {
            p.cause_food_exhaustion(0.1);
        }
        true
    }

    /// `Player.damageStatsAndHearts`: the damage dealt statistic, and the
    /// damage indicator particles over a target that lost more than 2 health
    /// (`feet` and `height`: the target's).
    pub(super) fn damage_stats_and_hearts(&mut self, actual: f32, feet: [f64; 3], height: f64) {
        self.award_custom_stat("damage_dealt", (actual * 10.0).round() as i32);
        if actual > 2.0 {
            let indicator = horizon_client::particles::ParticleOptions::simple(
                horizon_client::particles::ParticleType::DamageIndicator,
            );
            self.particles.send_particles(
                &indicator,
                [feet[0], feet[1] + height * 0.5, feet[2]],
                [0.1, 0.0, 0.1],
                0.2,
                (actual * 0.5) as u32,
            );
            // The players a server serves are sent them too (the window of the server thread).
            self.lan_send_particles(super::lan_particles::QueuedParticle {
                dimension: self.dim.id(),
                options: indicator,
                state: None,
                at: [feet[0], feet[1] + height * 0.5, feet[2]],
                spread: [0.1, 0.0, 0.1],
                speed: [0.2; 3],
                count: (actual * 0.5) as u32 as i32,
                randomization: 0,
            });
        }
    }

    /// `Player.cannotAttackWithItem` for the held item: a spear needs its
    /// `minimum_attack_charge` of 1, counting `tolerance` ticks more than the
    /// `ticker` ticks charged.
    pub(super) fn cannot_attack_with_item(&self, ticker: i32, tolerance: i32) -> bool {
        self.held().is_some_and(|s| Kinetic::of(&s.item).is_some())
            && (ticker + tolerance) as f32 / delay(self.main_hand_attack_speed()) < 1.0
    }

    /// `PiercingWeapon.attack` of the spear in the main hand, for a left
    /// click: every mob along the view is stabbed, then `postPiercingAttack`
    /// (Lunge), the hit sound and the swing. Gives the sound of the jab
    /// (`makeSound`), which everyone but the user hears from the server.
    pub(super) fn jab(&mut self) -> Option<&'static str> {
        let kinetic = self.held().and_then(|s| Kinetic::of(&s.item))?;
        let eye = self.eye_position()?;
        let eye = Vec3::new(eye[0], eye[1], eye[2]);
        let look = view_vector(self.yaw, self.pitch);
        let look = Vec3::new(look[0], look[1], look[2]);
        // The attack damage attribute.
        let damage = self.attack_damage();
        let movement = self.known_player_movement();
        let mut hit = false;
        let mut on_players = Vec::new();
        for target in self.stab_targets(eye, look, movement) {
            match target {
                Target::Mob(i) => hit |= self.stab_mob(i, damage, true, true, false),
                Target::Player(k) => {
                    on_players.extend(self.queue_player_stab(k, damage, true, true, false))
                }
            }
        }
        // Player.onAttack, then postPiercingAttack.
        self.attack_ticks = 0;
        self.post_piercing_attack();
        if hit {
            self.play_at_feet(kinetic.hit_sound);
        }
        self.keep_player_stabs(kinetic, false, hit, on_players);
        // swingAndResetAttackStrength (ServerPlayer): a swing that starts
        // resets the attack strength.
        let swings = self.swings_started;
        self.swing_hand(Hand::Main, kinetic.attack_animation());
        if self.swings_started != swings {
            self.reset_attack_strength();
        }
        Some(kinetic.attack_sound)
    }

    /// A sound at the player's feet.
    pub(super) fn play_at_feet(&mut self, sound: &str) {
        if let Some(p) = &self.player {
            let at = [p.position.x, p.position.y, p.position.z];
            self.audio.play(sound, Some(at), 1.0, 1.0);
        }
    }

    /// `LivingEntity.onKineticHit` for `entity`: the hit feels (the spear
    /// moves back, `kinetic_hit_ticks`) and sounds, at most once every ten
    /// ticks.
    pub(super) fn kinetic_hit_feedback(&mut self, entity: i32, kinetic: &Kinetic, at: [f64; 3]) {
        let now = self.world.game_time;
        if self
            .kinetic_feedback
            .get(&entity)
            .is_none_or(|&t| now - t > HIT_FEEDBACK_TICKS)
        {
            self.kinetic_feedback.insert(entity, now);
            self.audio
                .play_unshared(kinetic.hit_sound, Some(at), 1.0, 1.0);
        }
    }

    /// `getTicksSinceLastKineticHitFeedback` of this window's player.
    pub(super) fn kinetic_hit_ticks(&self, partial: f32) -> f32 {
        self.kinetic_feedback
            .get(&OWN)
            .map_or(0.0, |&t| (self.world.game_time - t) as f32 + partial)
    }

    /// `LivingEntity.handleEntityEvent(2)` on a server's client: the
    /// player `id` (this one, or another) was hit by the spear it uses.
    pub(super) fn remote_kinetic_hit(&mut self, id: i32) {
        let own = self.remote.as_ref().is_some_and(|r| r.entity_id == id);
        let (item, at) = if own {
            let item = self
                .using
                .and_then(|(slot, _)| self.stack_in(slot))
                .map(|s| s.item.clone());
            let at = self.player.as_ref().map(|p| p.position);
            (item, at)
        } else {
            let mob = self
                .mobs
                .iter()
                .find(|m| m.id == id as u32 && m.extra.using_item > 0);
            let item = mob.and_then(|m| {
                if m.extra.using_off_hand {
                    horizon_client::mobs::finalize::item(m, horizon_client::mobs::finalize::OFFHAND)
                } else {
                    horizon_client::mobs::finalize::item(
                        m,
                        horizon_client::mobs::finalize::MAINHAND,
                    )
                }
            });
            (item, mob.map(|m| m.position))
        };
        if let (Some(kinetic), Some(at)) = (item.as_deref().and_then(Kinetic::of), at) {
            self.kinetic_hit_feedback(if own { OWN } else { id }, &kinetic, [at.x, at.y, at.z]);
        }
    }
}
