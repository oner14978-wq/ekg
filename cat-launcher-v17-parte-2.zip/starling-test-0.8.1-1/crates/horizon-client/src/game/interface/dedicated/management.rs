//! The management protocol's list edits, which `horizon-server` forwards on the control endpoint as
//! `management <connection> {"method", "entries"}` (its management_methods.rs): vanilla 26.3's
//! `AllowlistService`, `BanlistService`, `IpBanlistService` and `OperatorService` on the running server's lists. Players are found as
//! `MinecraftPlayerListService.getUser` finds them, each change is logged as `JsonRpcLogger` logs it, and the
//! players a change shuts out are disconnected. The supervisor answers with the lists, from their files.
use super::{GAME_MODES, ServerState, auto_save, log, set_auto_save};
use crate::game::Game;
use horizon_client::{
    command::vanilla::DIFFICULTIES,
    gamerules::{self, Value as GameRuleValue},
    server::{
        profiles,
        user_lists::{BanEntry, NameAndId, OpEntry, WhiteEntry},
    },
    text::Text,
};
use horizon_protocol::text::translatable;
use serde_json::{Value, json};

/// A `UserBan`: the player, the reason, the source, the end.
type Ban = BanEntry<NameAndId>;
/// An `IpBan`: the address, the reason, the source, the end.
type IpBan = BanEntry<String>;

/// `OperatorService.Op`: the player and the level and bypass asked for, which a stored operator always has.
#[derive(PartialEq)]
struct Op {
    user: NameAndId,
    level: Option<i32>,
    bypass: Option<bool>,
}

/// A `GameRuleUpdate` as `TYPED_CODEC` writes it: the rule's id, its type and its value.
fn typed_rule(rule: &gamerules::Rule, value: GameRuleValue) -> Value {
    let (kind, value) = match value {
        GameRuleValue::Bool(b) => ("boolean", json!(b)),
        GameRuleValue::Int(i) => ("integer", json!(i)),
    };
    json!({ "key": rule.name.clone(), "type": kind, "value": value })
}

/// `NameAndId`'s record `toString`, as vanilla's log lines show it.
fn shown(user: &NameAndId) -> String {
    format!(
        "NameAndId[id={}, name={}]",
        horizon_protocol::crypto::uuid_string(user.id),
        user.name
    )
}

impl Game<'_> {
    pub(super) fn management(&mut self, state: &mut ServerState, request: &str) -> Value {
        let (connection, body) = request.split_once(' ').unwrap_or((request, "{}"));
        let rpc =
            |message: String| log("INFO", &format!("RPC Connection #{connection}: {message}"));
        let Ok(body) = serde_json::from_str::<Value>(body) else {
            return json!({ "error": "a management request is a connection number and a JSON object" });
        };
        let entries = body["entries"].as_array().cloned().unwrap_or_default();
        let lists = state.lists.clone();
        match body["method"].as_str().unwrap_or_default() {
            // `GameRulesService.get`: every rule the server has, with its type and current value.
            "gamerules" => {
                let rules = &self.ui.rules;
                let all: Vec<Value> = rules
                    .available_rules()
                    .map(|r| typed_rule(r, rules.get(&r.name).unwrap_or(r.default)))
                    .collect();
                return json!({ "value": all });
            }
            // `GameRulesService.update` through `MinecraftGameRuleServiceImpl.updateGameRule`: the rule is set,
            // logged and told on every update, even to the value it has (as vanilla's sends its notification
            // then too, which the parity script checks). What doesn't fit answers with the texts of vanilla's
            // codecs, as the parity script saw them.
            "gamerules/update" => {
                let update = &body["value"];
                let Some(key) = update["key"].as_str() else {
                    return json!({ "invalid": format!("No key key in MapLike[{update}]") });
                };
                let rule = self.ui.rules.rule(key).cloned();
                let Some(rule) = rule else {
                    let key = if key.contains(':') {
                        key.to_owned()
                    } else {
                        format!("minecraft:{key}")
                    };
                    return json!({ "invalid": format!(
                        "Unknown registry key in ResourceKey[minecraft:root / minecraft:game_rule]: {key}"
                    ) });
                };
                let wanted = &update["value"];
                let value = match (rule.default, wanted) {
                    (GameRuleValue::Bool(_), Value::Bool(b)) => Ok(GameRuleValue::Bool(*b)),
                    (GameRuleValue::Bool(_), other) => Err(format!("Not a boolean: {other}")),
                    (GameRuleValue::Int(_), other) => match other.as_i64() {
                        Some(n) if (i64::from(rule.min)..=i64::from(rule.max)).contains(&n) => {
                            Ok(GameRuleValue::Int(n as i32))
                        }
                        Some(n) => Err(format!(
                            "Value {n} outside of range [{}:{}]",
                            rule.min, rule.max
                        )),
                        None => Err(format!("Not a number: {other}")),
                    },
                };
                let value = match value {
                    Ok(value) => value,
                    Err(invalid) => return json!({ "invalid": invalid }),
                };
                let current = self.ui.rules.get(&rule.name).unwrap_or(rule.default);
                rpc(format!(
                    "Game rule '{}' updated from '{current}' to '{value}'",
                    rule.name
                ));
                self.set_game_rule(&rule, value, None);
                return json!({ "value": typed_rule(&rule, value) });
            }
            "serversettings/autosave" => {
                return json!({ "value": auto_save(state) });
            }
            "serversettings/autosave/set" => {
                let Some(enabled) = body["value"].as_bool() else {
                    return json!({ "error": "autosave must be a boolean" });
                };
                rpc(format!(
                    "Update autosave from {} to {}",
                    auto_save(state),
                    enabled
                ));
                set_auto_save(&state.lists, enabled);
                return json!({ "value": auto_save(state) });
            }
            "serversettings/pause_when_empty_seconds" => {
                return json!({ "value": state.pause_when_empty_seconds });
            }
            "serversettings/pause_when_empty_seconds/set" => {
                let Some(seconds) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                else {
                    return json!({ "error": "pause when empty seconds must be an integer" });
                };
                rpc(format!(
                    "Update pause when empty from {} seconds to {} seconds",
                    state.pause_when_empty_seconds, seconds
                ));
                self.set_pause_when_empty_seconds(state, seconds);
                return json!({ "value": state.pause_when_empty_seconds });
            }
            "serversettings/motd" => {
                return json!({
                    "value": self.lan.as_ref().map(|lan| lan.hub.lan.shared.motd()).unwrap_or_default()
                });
            }
            "serversettings/motd/set" => {
                let Some(value) = body["value"].as_str() else {
                    return json!({ "error": "MOTD must be a string" });
                };
                if let Some(lan) = &self.lan {
                    rpc(format!(
                        "Update MOTD from '{}' to '{}'",
                        lan.hub.lan.shared.motd(),
                        value
                    ));
                    lan.hub.lan.shared.set_motd(value.to_owned());
                }
                // DedicatedServer.setMotd: server.properties keeps it too.
                self.store_property("motd", value.to_owned());
                return json!({ "value": value });
            }
            "serversettings/game_mode" => {
                return json!({ "value": GAME_MODES[state.game_mode as usize] });
            }
            "serversettings/game_mode/set" => {
                let Some(value) = body["value"].as_str() else {
                    return json!({ "error": "game mode must be a string" });
                };
                let Some(index) = GAME_MODES.iter().position(|name| *name == value) else {
                    return json!({ "error": format!("unknown game mode {value:?}") });
                };
                rpc(format!(
                    "Update game mode from '{}' to '{}'",
                    GAME_MODES[state.game_mode as usize], value
                ));
                self.store_property("gamemode", value.to_owned());
                state.game_mode = index as i32;
                self.set_default_game_mode(state.game_mode);
                return json!({ "value": GAME_MODES[state.game_mode as usize] });
            }
            "serversettings/entity_broadcast_range" => {
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .map_or(100, |host| host.hub.entity_range_percent)
                });
            }
            "serversettings/entity_broadcast_range/set" => {
                let Some(percentage) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                else {
                    return json!({
                        "error": "entity broadcast range percentage must be an integer"
                    });
                };
                let current = self
                    .lan
                    .as_ref()
                    .map_or(100, |host| host.hub.entity_range_percent);
                // MinecraftServerSettingsServiceImpl logs the value asked for; the
                // DedicatedServerProperties deserializer clamps what is applied and saved.
                rpc(format!(
                    "Update entity broadcast range percentage from {current}% to {percentage}%"
                ));
                let percentage = percentage.clamp(10, 1000);
                self.set_entity_broadcast_range_percentage(percentage);
                self.store_property("entity-broadcast-range-percentage", percentage.to_string());
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .map_or(100, |host| host.hub.entity_range_percent)
                });
            }
            "serversettings/simulation_distance" => {
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .map_or(0, |host| host.hub.config.simulation_distance)
                });
            }
            "serversettings/simulation_distance/set" => {
                let Some(distance) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                else {
                    return json!({ "error": "simulation distance must be an integer" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .map_or(0, |host| host.hub.config.simulation_distance);
                rpc(format!(
                    "Update simulation distance from {current} to {distance}"
                ));
                self.set_simulation_distance(distance);
                state.view.1 = distance.max(0) as u32;
                self.store_property("simulation-distance", distance.to_string());
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .map_or(0, |host| host.hub.config.simulation_distance)
                });
            }
            "serversettings/view_distance" => {
                return json!({
                    "value": self.lan.as_ref().map_or(0, |host| host.hub.config.view_distance)
                });
            }
            "serversettings/view_distance/set" => {
                let Some(distance) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                else {
                    return json!({ "error": "view distance must be an integer" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .map_or(0, |host| host.hub.config.view_distance);
                rpc(format!("Update view distance from {current} to {distance}"));
                self.set_view_distance(distance);
                state.view.0 = distance.max(0) as u32;
                self.store_property("view-distance", distance.to_string());
                return json!({
                    "value": self.lan.as_ref().map_or(0, |host| host.hub.config.view_distance)
                });
            }
            "serversettings/operator_user_permission_level" => {
                return json!({ "value": state.op_level });
            }
            "serversettings/operator_user_permission_level/set" => {
                let Some(level) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                    .filter(|level| (0..=4).contains(level))
                else {
                    return json!({
                        "error": "operator user permission level must be an integer between 0 and 4"
                    });
                };
                rpc(format!(
                    "Update operator user permission level from {} to {}",
                    state.op_level, level
                ));
                state.op_level = level;
                state.lists.lock().unwrap().op_level = level;
                self.store_property("op-permission-level", level.to_string());
                return json!({ "value": state.op_level });
            }
            "serversettings/force_game_mode" => {
                return json!({ "value": state.force_game_mode });
            }
            "serversettings/force_game_mode/set" => {
                let Some(force) = body["value"].as_bool() else {
                    return json!({ "error": "force game mode must be a boolean" });
                };
                rpc(format!(
                    "Update force game mode from {} to {}",
                    state.force_game_mode, force
                ));
                self.store_property("force-gamemode", force.to_string());
                state.force_game_mode = force;
                self.set_force_game_mode(force);
                return json!({ "value": state.force_game_mode });
            }
            "serversettings/spawn_protection_radius" => {
                return json!({
                    "value": self.lan.as_ref().map_or(0, |host| host.hub.spawn_protection)
                });
            }
            "serversettings/spawn_protection_radius/set" => {
                let Some(radius) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                else {
                    return json!({ "error": "spawn protection radius must be an integer" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .map_or(0, |host| host.hub.spawn_protection);
                rpc(format!(
                    "Update spawn protection radius from {current} to {radius}"
                ));
                self.set_spawn_protection(radius);
                self.store_property("spawn-protection", radius.to_string());
                return json!({
                    "value": self.lan.as_ref().map_or(0, |host| host.hub.spawn_protection)
                });
            }
            "serversettings/allow_flight" => {
                return json!({
                    "value": self.lan.as_ref().is_some_and(|host| host.hub.config.allow_flight)
                });
            }
            "serversettings/allow_flight/set" => {
                let Some(allow) = body["value"].as_bool() else {
                    return json!({ "error": "allow flight must be a boolean" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .is_some_and(|host| host.hub.config.allow_flight);
                rpc(format!("Update allow flight from {current} to {allow}"));
                self.set_allow_flight(allow);
                self.store_property("allow-flight", allow.to_string());
                return json!({
                    "value": self.lan.as_ref().is_some_and(|host| host.hub.config.allow_flight)
                });
            }
            "serversettings/hide_online_players" => {
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .is_some_and(|host| host.hub.lan.shared.hide_online_players())
                });
            }
            "serversettings/hide_online_players/set" => {
                let Some(hide) = body["value"].as_bool() else {
                    return json!({ "error": "hide online players must be a boolean" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .is_some_and(|host| host.hub.lan.shared.hide_online_players());
                rpc(format!(
                    "Update hide online players from {current} to {hide}"
                ));
                self.set_hide_online_players(hide);
                self.store_property("hide-online-players", hide.to_string());
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .is_some_and(|host| host.hub.lan.shared.hide_online_players())
                });
            }
            "serversettings/status_replies" => {
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .is_some_and(|host| host.hub.lan.shared.enable_status())
                });
            }
            "serversettings/status_replies/set" => {
                let Some(enable) = body["value"].as_bool() else {
                    return json!({ "error": "status replies must be a boolean" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .is_some_and(|host| host.hub.lan.shared.enable_status());
                rpc(format!("Update status replies from {current} to {enable}"));
                self.set_status_replies(enable);
                self.store_property("enable-status", enable.to_string());
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .is_some_and(|host| host.hub.lan.shared.enable_status())
                });
            }
            "serversettings/accept_transfers" => {
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .is_some_and(|host| host.hub.lan.shared.accepts_transfers())
                });
            }
            "serversettings/accept_transfers/set" => {
                let Some(accept) = body["value"].as_bool() else {
                    return json!({ "error": "accepts transfers must be a boolean" });
                };
                let current = self
                    .lan
                    .as_ref()
                    .is_some_and(|host| host.hub.lan.shared.accepts_transfers());
                rpc(format!(
                    "Update accepts transfers from {current} to {accept}"
                ));
                self.set_accepts_transfers(accept);
                return json!({
                    "value": self
                        .lan
                        .as_ref()
                        .is_some_and(|host| host.hub.lan.shared.accepts_transfers())
                });
            }
            "serversettings/player_idle_timeout" => {
                return json!({ "value": state.lists.lock().unwrap().player_idle_timeout });
            }
            "serversettings/player_idle_timeout/set" => {
                let Some(minutes) = body["value"]
                    .as_i64()
                    .and_then(|value| i32::try_from(value).ok())
                else {
                    return json!({ "error": "player idle timeout must be an integer" });
                };
                rpc(format!(
                    "Update player idle timeout from {} minutes to {} minutes",
                    state.lists.lock().unwrap().player_idle_timeout,
                    minutes
                ));
                self.set_player_idle_timeout(&state.lists.clone(), minutes);
                return json!({ "value": state.lists.lock().unwrap().player_idle_timeout });
            }
            "serversettings/max_players" => {
                return json!({ "value": state.max_players });
            }
            "serversettings/max_players/set" => {
                let Some(max_players) = body["value"]
                    .as_i64()
                    .and_then(|value| usize::try_from(value).ok())
                else {
                    return json!({ "error": "max players must be a non-negative integer" });
                };
                rpc(format!(
                    "Update max players from {} to {}",
                    state.max_players, max_players
                ));
                self.set_max_players(state, max_players);
                return json!({ "value": state.max_players });
            }
            "serversettings/use_allowlist" => {
                return json!({
                    "value": lists.lock().unwrap().use_whitelist
                });
            }
            "serversettings/use_allowlist/set" => {
                let Some(use_allowlist) = body["value"].as_bool() else {
                    return json!({ "error": "using allowlist must be a boolean" });
                };
                let current = lists.lock().unwrap().use_whitelist;
                rpc(format!(
                    "Update using allowlist from {} to {}",
                    current, use_allowlist
                ));
                self.set_using_whitelist(&lists, use_allowlist);
                self.kick_unlisted_players(&lists);
                return json!({
                    "value": lists.lock().unwrap().use_whitelist
                });
            }
            "serversettings/enforce_allowlist" => {
                return json!({
                    "value": lists.lock().unwrap().enforce_whitelist
                });
            }
            "serversettings/enforce_allowlist/set" => {
                let Some(enforce) = body["value"].as_bool() else {
                    return json!({ "error": "enforce allowlist must be a boolean" });
                };
                let current = lists.lock().unwrap().enforce_whitelist;
                rpc(format!(
                    "Update enforce allowlist from {} to {}",
                    current, enforce
                ));
                self.set_enforce_whitelist(&lists, enforce);
                self.kick_unlisted_players(&lists);
                return json!({
                    "value": lists.lock().unwrap().enforce_whitelist
                });
            }
            "serversettings/difficulty" => {
                return json!({ "value": DIFFICULTIES[self.level.difficulty_id() as usize] });
            }
            "serversettings/difficulty/set" => {
                let Some(value) = body["value"].as_str() else {
                    return json!({ "error": "difficulty must be a string" });
                };
                let Some(index) = DIFFICULTIES.iter().position(|name| *name == value) else {
                    return json!({ "error": format!("unknown difficulty {value:?}") });
                };
                rpc(format!(
                    "Update difficulty from '{}' to '{}'",
                    DIFFICULTIES[self.level.difficulty_id() as usize],
                    value
                ));
                // DedicatedServer.setDifficulty stores the property and then forces the world
                // difficulty, including hardcore's always-hard rule and the player broadcast.
                self.store_property("difficulty", value.to_owned());
                self.set_difficulty_forced(if self.level.hardcore { 3 } else { index as u8 });
                return json!({ "value": DIFFICULTIES[self.level.difficulty_id() as usize] });
            }
            "allowlist/add" => {
                for user in entries.iter().filter_map(|e| self.management_user(e)) {
                    rpc(format!("Add player '{}' to allowlist", shown(&user)));
                    lists.lock().unwrap().white.add(WhiteEntry { user });
                }
            }
            "allowlist/remove" => {
                for user in entries.iter().filter_map(|e| self.management_user(e)) {
                    rpc(format!("Remove player '{}' from allowlist", shown(&user)));
                    lists.lock().unwrap().white.remove(&user);
                }
                rpc("Kick unlisted players".into());
                self.kick_unlisted_players(&lists);
            }
            "allowlist/set" => {
                let wanted: Vec<NameAndId> = entries
                    .iter()
                    .filter_map(|e| self.management_user(e))
                    .collect();
                let current: Vec<NameAndId> = lists
                    .lock()
                    .unwrap()
                    .white
                    .entries()
                    .iter()
                    .map(|e| e.user.clone())
                    .collect();
                for user in current.iter().filter(|u| !wanted.contains(u)) {
                    rpc(format!("Remove player '{}' from allowlist", shown(user)));
                    lists.lock().unwrap().white.remove(user);
                }
                for user in wanted.iter().filter(|u| !current.contains(u)) {
                    rpc(format!("Add player '{}' to allowlist", shown(user)));
                    lists
                        .lock()
                        .unwrap()
                        .white
                        .add(WhiteEntry { user: user.clone() });
                }
                rpc("Kick unlisted players".into());
                self.kick_unlisted_players(&lists);
            }
            "allowlist/clear" => {
                rpc("Clear allowlist".into());
                lists.lock().unwrap().white.clear();
            }
            "bans/add" => {
                let bans: Vec<Ban> = entries
                    .iter()
                    .filter_map(|e| self.management_ban(e))
                    .collect();
                for ban in bans {
                    self.management_add_ban(&rpc, state, ban);
                }
            }
            "bans/remove" => {
                for user in entries.iter().filter_map(|e| self.management_user(e)) {
                    rpc(format!("Remove player '{}' from banlist", shown(&user)));
                    lists.lock().unwrap().bans.remove(&user);
                }
            }
            "bans/set" => {
                let wanted: Vec<Ban> = entries
                    .iter()
                    .filter_map(|e| self.management_ban(e))
                    .collect();
                let current: Vec<Ban> = lists
                    .lock()
                    .unwrap()
                    .bans
                    .entries()
                    .into_iter()
                    .cloned()
                    .collect();
                for ban in current.iter().filter(|b| !wanted.contains(b)) {
                    rpc(format!("Remove player '{}' from banlist", shown(&ban.user)));
                    lists.lock().unwrap().bans.remove(&ban.user);
                }
                for ban in wanted.into_iter().filter(|b| !current.contains(b)) {
                    self.management_add_ban(&rpc, state, ban);
                }
            }
            // MinecraftBanListServiceImpl.clearUserBans logs nothing.
            "bans/clear" => lists.lock().unwrap().bans.clear(),
            "ip_bans/add" => {
                for entry in &entries {
                    // An address, else the address of the player named, if online.
                    let ip = entry["ip"]
                        .as_str()
                        .filter(|ip| ip.parse::<std::net::IpAddr>().is_ok());
                    let ip = ip.map(str::to_owned).or_else(|| {
                        let player = entry.get("player")?;
                        self.management_online(player).map(|(_, ip)| ip)
                    });
                    if let Some(ip) = ip {
                        self.management_ip_ban(&rpc, state, management_ip_ban(entry, ip));
                    }
                }
            }
            "ip_bans/remove" => {
                for ip in entries.iter().filter_map(|e| e["ip"].as_str()) {
                    rpc(format!("Remove ip '{ip}' from ban list"));
                    lists.lock().unwrap().ip_bans.remove(&ip.to_owned());
                }
            }
            "ip_bans/set" => {
                let wanted: Vec<IpBan> = entries
                    .iter()
                    .filter_map(|e| {
                        let ip = e["ip"]
                            .as_str()
                            .filter(|ip| ip.parse::<std::net::IpAddr>().is_ok())?;
                        Some(management_ip_ban(e, ip.to_owned()))
                    })
                    .collect();
                let current: Vec<IpBan> = lists
                    .lock()
                    .unwrap()
                    .ip_bans
                    .entries()
                    .into_iter()
                    .cloned()
                    .collect();
                for ban in current.iter().filter(|b| !wanted.contains(b)) {
                    rpc(format!("Remove ip '{}' from ban list", ban.user));
                    lists.lock().unwrap().ip_bans.remove(&ban.user);
                }
                for ban in wanted.into_iter().filter(|b| !current.contains(b)) {
                    self.management_ip_ban(&rpc, state, ban);
                }
            }
            "ip_bans/clear" => {
                rpc("Clear ip ban list".into());
                lists.lock().unwrap().ip_bans.clear();
            }
            "operators/add" => {
                let ops: Vec<Op> = entries
                    .iter()
                    .filter_map(|e| self.management_op(e))
                    .collect();
                for op in ops {
                    self.management_add_op(&rpc, state, op);
                }
            }
            "operators/remove" => {
                let users: Vec<_> = entries
                    .iter()
                    .filter_map(|e| self.management_user(e))
                    .collect();
                for user in users {
                    rpc(format!("Deop '{}'", shown(&user)));
                    let known = lists.lock().unwrap().ops.contains(&user);
                    if known && self.permission_change(&lists, &user, 0) {
                        continue;
                    }
                    lists.lock().unwrap().ops.remove(&user);
                }
                self.sync_ops(&lists);
            }
            "operators/set" => {
                let wanted: Vec<Op> = entries
                    .iter()
                    .filter_map(|e| self.management_op(e))
                    .collect();
                let current: Vec<Op> = lists
                    .lock()
                    .unwrap()
                    .ops
                    .entries()
                    .iter()
                    .map(|e| Op {
                        user: e.user.clone(),
                        level: Some(e.level),
                        bypass: Some(e.bypasses_player_limit),
                    })
                    .collect();
                for op in current.iter().filter(|o| !wanted.contains(o)) {
                    rpc(format!("Deop '{}'", shown(&op.user)));
                    if self.permission_change(&lists, &op.user, 0) {
                        continue;
                    }
                    lists.lock().unwrap().ops.remove(&op.user);
                }
                for op in wanted.into_iter().filter(|o| !current.contains(o)) {
                    self.management_add_op(&rpc, state, op);
                }
                self.sync_ops(&lists);
            }
            "operators/clear" => {
                rpc("Clear operator list".into());
                lists.lock().unwrap().ops.clear();
                self.sync_ops(&lists);
            }
            other => return json!({ "error": format!("unknown management method {other:?}") }),
        }
        json!({ "ok": true })
    }

    /// `addUserBan`, then the banned player, if online, is sent away.
    fn management_add_ban(&mut self, rpc: &impl Fn(String), state: &ServerState, ban: Ban) {
        let reason = ban.reason.clone().unwrap_or_else(|| {
            Text::translate("multiplayer.disconnect.banned.reason.default", &[]).plain()
        });
        rpc(format!(
            "Add player '{}' to banlist. Reason: '{reason}'",
            ban.user.name
        ));
        let id = ban.user.id;
        state.lists.lock().unwrap().bans.add(ban);
        self.kick_uuid(id, translatable("multiplayer.disconnect.banned", &[]));
    }

    /// `addIpBan`, then whoever is online from that address is sent away.
    fn management_ip_ban(&mut self, rpc: &impl Fn(String), state: &ServerState, ban: IpBan) {
        rpc(format!("Add ip '{}' to ban list", ban.user));
        let ip = ban.user.clone();
        state.lists.lock().unwrap().ip_bans.add(ban);
        let banned = self.ip_ban_players(&ip);
        for uuid in banned {
            self.kick_uuid(uuid, translatable("multiplayer.disconnect.ip_banned", &[]));
        }
    }

    /// `PlayerList.op`: the level asked for, else `op-permission-level`; the bypass asked for, else the one
    /// the player had. The commands an online player may run follow (`sync_ops`, after the edit).
    fn management_add_op(&mut self, rpc: &impl Fn(String), state: &ServerState, op: Op) {
        rpc(format!("Op '{}'", shown(&op.user)));
        let level = op
            .level
            .unwrap_or_else(|| state.lists.lock().unwrap().op_level);
        if self.permission_change(&state.lists, &op.user, level) {
            return;
        }
        let mut lists = state.lists.lock().unwrap();
        let had = lists
            .ops
            .get(&op.user)
            .is_some_and(|e| e.bypasses_player_limit);
        let entry = OpEntry {
            level: op.level.unwrap_or(lists.op_level),
            bypasses_player_limit: op.bypass.unwrap_or(had),
            user: op.user,
        };
        lists.ops.add(entry);
        drop(lists);
        self.sync_ops(&state.lists);
    }

    /// An `OperatorDto`: the player found, and the level and bypass when given.
    fn management_op(&self, entry: &Value) -> Option<Op> {
        Some(Op {
            user: self.management_user(&entry["player"])?,
            level: entry["permissionLevel"].as_i64().map(|l| l as i32),
            bypass: entry["bypassesPlayerLimit"].as_bool(),
        })
    }

    /// `PlayerListService.getPlayer(id, name)`: an online player, by id first; their address.
    fn management_online(&self, player: &Value) -> Option<(u128, String)> {
        let id = player["id"]
            .as_str()
            .and_then(|s| u128::from_str_radix(s, 16).ok());
        let name = player["name"].as_str();
        let guest = self
            .lan
            .as_ref()?
            .hub
            .guests
            .iter()
            .filter(|g| g.participates_online())
            .find(|g| match (id, name) {
                (Some(id), _) => g.uuid == id,
                (None, Some(name)) => g.name.eq_ignore_ascii_case(name),
                (None, None) => false,
            })?;
        Some((guest.uuid, guest.address.ip().to_string()))
    }

    /// `UserBanDto.toUserBan`: the player found, the source "Management server" unless one is given; the ban
    /// starts now.
    fn management_ban(&self, entry: &Value) -> Option<Ban> {
        let user = self.management_user(&entry["player"])?;
        let source = entry["source"].as_str().unwrap_or("Management server");
        let reason = entry["reason"].as_str().map(str::to_owned);
        Some(BanEntry::new(
            user,
            Some(source.to_owned()),
            entry["expires"].as_i64(),
            reason,
        ))
    }

    /// `MinecraftPlayerListService.getUser`: by id, the user cache, else the session service; by name, the
    /// user cache, else the profile service (an offline server's offline player).
    fn management_user(&self, player: &Value) -> Option<NameAndId> {
        if let Some(id) = player["id"]
            .as_str()
            .and_then(|s| u128::from_str_radix(s, 16).ok())
        {
            let cached = super::USER_CACHE
                .lock()
                .unwrap()
                .as_mut()
                .and_then(|c| c.get_by_id(id));
            return cached.or_else(|| profiles::find_by_id(&profiles::discovery_url(), id));
        }
        self.resolve_name(player["name"].as_str()?)
    }
}

/// `IpBan`: the reason, the source "Management server" unless one is given, the end; it starts now.
fn management_ip_ban(entry: &Value, ip: String) -> IpBan {
    let source = entry["source"].as_str().unwrap_or("Management server");
    let reason = entry["reason"].as_str().map(str::to_owned);
    BanEntry::new(
        ip,
        Some(source.to_owned()),
        entry["expires"].as_i64(),
        reason,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES"]
    fn management_online_skips_fake_players_by_name_and_id() {
        crate::game::native_guest_turn_tests::with_guests(|game| {
            let level = game.level("minecraft:overworld").unwrap();
            game.fake_player(level, 100, "robot").unwrap();
            assert_eq!(game.management_online(&json!({"name": "robot"})), None);
            assert_eq!(game.management_online(&json!({"id": "64"})), None);
            assert_eq!(
                game.management_online(&json!({"name": "GUEST12"})),
                Some((12, "127.0.0.1".into()))
            );
            // Id takes precedence, with no fallback from a fake id to a real name.
            assert_eq!(
                game.management_online(&json!({"id": "c", "name": "robot"})),
                Some((12, "127.0.0.1".into()))
            );
            assert_eq!(
                game.management_online(&json!({"id": "64", "name": "guest12"})),
                None
            );
        });
    }

    #[test]
    fn a_game_rule_is_written_as_vanillas_typed_codec_does() {
        let pvp = gamerules::rule_registry().rule("pvp").unwrap().clone();
        assert_eq!(
            typed_rule(&pvp, GameRuleValue::Bool(false)),
            json!({ "key": "minecraft:pvp", "type": "boolean", "value": false })
        );
        let tick = gamerules::rule_registry()
            .rule("minecraft:random_tick_speed")
            .unwrap()
            .clone();
        assert_eq!(
            typed_rule(&tick, GameRuleValue::Int(3)),
            json!({ "key": "minecraft:random_tick_speed", "type": "integer", "value": 3 })
        );
    }
}
