//! The control API's admin endpoints (docs/api/server.md): who is online and on vanilla's lists, the
//! moderation actions, and the metrics as text for a monitoring tool.
//!
//! An action runs the vanilla console command on the running game (kick, ban, ban-ip, pardon, pardon-ip,
//! op, deop, whitelist), so it does exactly what an operator's command does, kicks included. The reply has
//! the console's lines and `changed`: whether the list file (or, for a kick, who is online) changed.

use crate::{
    api::{Phase, Shared},
    engine,
    http::Response,
};
use horizon_platform::server_files::user_lists::{
    BanList, IpBanList, OpList, UserList, WhiteList, format_date,
};
use horizon_server_launch::{self as launch, config};
use serde_json::{Value, json};
use std::{fmt::Write, path::Path, sync::Mutex};

/// One action at a time, so `changed` compares the files around this action only.
static ACTING: Mutex<()> = Mutex::new(());

/// The longest reason taken (vanilla's chat line is 256).
const MAX_REASON: usize = 256;

/// A moderation action: its console command and the file it changes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Action {
    Kick,
    Ban,
    Pardon,
    BanIp,
    PardonIp,
    Op,
    Deop,
    WhitelistAdd,
    WhitelistRemove,
    Whitelist,
}

impl Action {
    /// The file whose change says the action did something (none for a kick).
    fn file(self) -> Option<&'static str> {
        match self {
            Self::Kick => None,
            Self::Ban | Self::Pardon => Some("banned-players.json"),
            Self::BanIp | Self::PardonIp => Some("banned-ips.json"),
            Self::Op | Self::Deop => Some("ops.json"),
            Self::WhitelistAdd | Self::WhitelistRemove => Some("whitelist.json"),
            Self::Whitelist => Some("server.properties"),
        }
    }

    /// The console line for a request body, or what is wrong with it.
    pub fn line(self, body: &Value) -> Result<String, String> {
        let name = || {
            let name = body["name"].as_str().unwrap_or_default();
            if (1..=16).contains(&name.chars().count())
                && name.chars().all(|c| !c.is_whitespace() && !c.is_control())
            {
                Ok(name)
            } else {
                Err(
                    "the body needs \"name\": a player's name (1 to 16 characters, no spaces)"
                        .to_owned(),
                )
            }
        };
        let ip = || {
            body["ip"]
                .as_str()
                .filter(|ip| ip.parse::<std::net::IpAddr>().is_ok())
                .ok_or_else(|| "the body needs \"ip\": an IPv4 or IPv6 address".to_owned())
        };
        let reason = || match body["reason"].as_str().map(str::trim) {
            None | Some("") => Ok(String::new()),
            Some(r) if r.chars().count() <= MAX_REASON && !r.chars().any(char::is_control) => {
                Ok(format!(" {r}"))
            }
            Some(_) => Err(format!(
                "\"reason\" is one line of at most {MAX_REASON} characters"
            )),
        };
        Ok(match self {
            Self::Kick => format!("kick {}{}", name()?, reason()?),
            Self::Ban => format!("ban {}{}", name()?, reason()?),
            Self::Pardon => format!("pardon {}", name()?),
            // An online player's name bans the address they play from, as vanilla's /ban-ip does.
            Self::BanIp => format!("ban-ip {}{}", ip().or_else(|_| name())?, reason()?),
            Self::PardonIp => format!("pardon-ip {}", ip()?),
            Self::Op => format!("op {}", name()?),
            Self::Deop => format!("deop {}", name()?),
            Self::WhitelistAdd => format!("whitelist add {}", name()?),
            Self::WhitelistRemove => format!("whitelist remove {}", name()?),
            Self::Whitelist => match body["enabled"].as_bool() {
                Some(true) => "whitelist on".into(),
                Some(false) => "whitelist off".into(),
                None => return Err("the body needs \"enabled\": true or false".into()),
            },
        })
    }
}

fn running(shared: &Shared) -> Result<engine::Control, Response> {
    if shared.state.lock().unwrap().phase != Phase::Running {
        return Err(Response::error(409, "the game isn't running right now"));
    }
    engine::Control::connect(&shared.dir)
        .map_err(|e| Response::error(409, &format!("the game didn't answer: {e}")))
}

/// The online players the game reports (`server-status`).
fn online(game: &mut engine::Control) -> Result<Value, Response> {
    game.ask("server-status")
        .map_err(|e| Response::error(409, &format!("the game didn't answer: {e}")))
}

/// `POST /api/v1/players/<action>` and `/api/v1/whitelist[/...]`.
pub fn act(shared: &Shared, action: Action, body: &[u8]) -> Response {
    let body: Value = serde_json::from_slice(body).unwrap_or(Value::Null);
    let line = match action.line(&body) {
        Ok(line) => line,
        Err(e) => return Response::error(400, &e),
    };
    if shared.phase() == Phase::Stopped
        && let Some((command, args)) = stopped_command(action, &body)
    {
        return match crate::lists::edit_stopped(&shared.dir, command, &args) {
            Ok(edit) => Response::json(
                200,
                &json!({ "changed": edit.changed, "output": [edit.message] }),
            ),
            Err(e) => Response::error(409, &e),
        };
    }
    let mut game = match running(shared) {
        Ok(game) => game,
        Err(response) => return response,
    };
    let _one = ACTING.lock().unwrap_or_else(|e| e.into_inner());
    let read = |file: &str| std::fs::read(shared.dir.join(file)).ok();
    let before = match action.file() {
        Some(file) => read(file),
        None => {
            let status = match online(&mut game) {
                Ok(status) => status,
                Err(response) => return response,
            };
            let name = body["name"].as_str().unwrap_or_default();
            let here = status["players"].as_array().into_iter().flatten().any(|p| {
                p["name"]
                    .as_str()
                    .is_some_and(|n| n.eq_ignore_ascii_case(name))
            });
            Some(vec![u8::from(here)])
        }
    };
    let reply = match game.ask(&format!("console {line}")) {
        Ok(reply) => reply,
        Err(e) => return Response::error(409, &format!("the game didn't answer: {e}")),
    };
    let changed = match action.file() {
        Some(file) => read(file) != before,
        None => before == Some(vec![1]),
    };
    crate::supervisor::note(shared, "INFO", &format!("Control API: {line}"));
    Response::json(
        200,
        &json!({ "changed": changed, "output": reply["output"] }),
    )
}

/// The actions that can edit files without a game process.
fn stopped_command(action: Action, body: &Value) -> Option<(&'static str, Vec<&str>)> {
    match action {
        Action::Op => Some(("op", vec![body["name"].as_str()?])),
        Action::Deop => Some(("deop", vec![body["name"].as_str()?])),
        Action::WhitelistAdd => Some(("whitelist", vec!["add", body["name"].as_str()?])),
        Action::WhitelistRemove => Some(("whitelist", vec!["remove", body["name"].as_str()?])),
        Action::Whitelist => Some((
            "whitelist",
            vec![if body["enabled"].as_bool()? {
                "on"
            } else {
                "off"
            }],
        )),
        _ => None,
    }
}

/// A list from its file in the server folder; missing or broken reads as empty, as the game would start.
fn load<E: horizon_platform::server_files::user_lists::Entry>(
    dir: &Path,
    file: &str,
) -> UserList<E> {
    let mut list = UserList::new(dir.join(file));
    let _ = list.load();
    list
}

/// The inventory response at the engine control boundary.
#[derive(serde::Deserialize)]
struct RuntimeMods {
    mods: Vec<RuntimeMod>,
}

#[derive(serde::Deserialize, serde::Serialize)]
struct RuntimeMod {
    id: String,
    version: String,
}

/// `GET /api/v1/mods`: the running engine's package inventory, with build provenance kept separate.
pub fn mods(shared: &Shared) -> Response {
    let mut game = match running(shared) {
        Ok(game) => game,
        Err(response) => return response,
    };
    let reply = match game.ask("server-mods") {
        Ok(reply) => reply,
        Err(e) => return Response::error(409, &format!("the game didn't answer: {e}")),
    };
    let runtime: RuntimeMods = match serde_json::from_value(reply) {
        Ok(runtime) => runtime,
        Err(e) => {
            return Response::error(
                409,
                &format!("the game's mod inventory is unavailable: {e}"),
            );
        }
    };
    let built = config::Config::load(&shared.dir)
        .ok()
        .and_then(|c| launch::program_in(&c, &shared.dir, shared.install.as_ref()).ok())
        .and_then(|p| std::fs::read_to_string(p.with_file_name("native-mods.json")).ok());
    Response::json(
        200,
        &json!({ "mods": runtime.mods, "provenance": built_with(built.as_deref()) }),
    )
}

/// Build provenance from `native-mods.json` (None: no program, or no such file).
fn built_with(built: Option<&str>) -> Value {
    let info: Value = built
        .and_then(|b| serde_json::from_str(b).ok())
        .unwrap_or(Value::Null);
    let native: Vec<Value> = info["mods"]
        .as_array()
        .into_iter()
        .flatten()
        .map(|m| json!({ "id": m["id"], "version": m["version"], "sha256": m["sha256"] }))
        .collect();
    json!({
        "engine": {
            "found": built.is_some(),
            "target": info["target"],
            "base": info["base"],
            "horizon": info["horizon"],
            "hooks": info["hooks"],
        },
        "native": native,
    })
}

/// `GET /api/v1/players`: who is online, and vanilla's lists.
pub fn players(shared: &Shared) -> Response {
    let dir = &shared.dir;
    let game = match running(shared) {
        Ok(mut game) => online(&mut game).ok(),
        Err(_) => None,
    };
    let ops: OpList = load(dir, "ops.json");
    let ops: Vec<Value> = ops
        .entries()
        .iter()
        .map(|e| json!({ "name": e.user.name, "uuid": uuid(e.user.id), "level": e.level }))
        .collect();
    let op_level = |id: &str| {
        ops.iter()
            .find(|o| o["uuid"] == id)
            .map(|o| o["level"].clone())
    };
    let online: Vec<Value> = game
        .as_ref()
        .and_then(|g| g["players"].as_array())
        .into_iter()
        .flatten()
        .map(|p| {
            let mut p = p.clone();
            p["op_level"] = op_level(p["uuid"].as_str().unwrap_or_default()).unwrap_or(json!(0));
            p
        })
        .collect();
    let white: WhiteList = load(dir, "whitelist.json");
    let bans: BanList = load(dir, "banned-players.json");
    let ip_bans: IpBanList = load(dir, "banned-ips.json");
    let ban = |created: i64, source: &str, expires: Option<i64>, reason: &Option<String>| {
        json!({
            "created": format_date(created),
            "source": source,
            "expires": expires.map(format_date),
            "reason": reason,
        })
    };
    Response::json(
        200,
        &json!({
            "online": online,
            "max_players": game.as_ref().map(|g| g["max_players"].clone()),
            "ops": ops,
            "whitelist": {
                "enabled": whitelist_on(dir),
                "players": white.entries().iter()
                    .map(|e| json!({ "name": e.user.name, "uuid": uuid(e.user.id) }))
                    .collect::<Vec<_>>(),
            },
            "bans": bans.entries().iter().map(|b| {
                let mut v = ban(b.created, &b.source, b.expires, &b.reason);
                v["name"] = json!(b.user.name);
                v["uuid"] = json!(uuid(b.user.id));
                v
            }).collect::<Vec<_>>(),
            "ip_bans": ip_bans.entries().iter().map(|b| {
                let mut v = ban(b.created, &b.source, b.expires, &b.reason);
                v["ip"] = json!(b.user);
                v
            }).collect::<Vec<_>>(),
        }),
    )
}

/// A UUID as the lists and the game write it (8-4-4-4-12 hex digits).
fn uuid(id: u128) -> String {
    let h = format!("{id:032x}");
    format!(
        "{}-{}-{}-{}-{}",
        &h[..8],
        &h[8..12],
        &h[12..16],
        &h[16..20],
        &h[20..]
    )
}

/// Whether the whitelist is on: the game writes `white-list` to server.properties when `/whitelist on|off`
/// changes it; server.toml catches up when it stops.
fn whitelist_on(dir: &Path) -> bool {
    std::fs::read(dir.join(config::PROPERTIES))
        .ok()
        .and_then(|b| {
            horizon_platform::server_files::java_properties::Properties::load_file(&b).ok()
        })
        .and_then(|p| p.get("white-list").map(|v| v == "true"))
        .or_else(|| config::Config::load(dir).ok().map(|c| c.server.whitelist))
        .unwrap_or(false)
}

/// `GET /api/v1/metrics/prometheus`: the latest sample in Prometheus's text format, for any monitoring
/// tool that scrapes it.
pub fn prometheus(shared: &Shared) -> Response {
    let (phase, crashes, sample) = {
        let state = shared.state.lock().unwrap();
        (state.phase, state.crashes, state.sample.clone())
    };
    let game = &sample["game"];
    let mut out = String::new();
    let mut gauge = |name: &str, help: &str, values: &[(&str, Option<f64>)]| {
        if values.iter().all(|(_, v)| v.is_none()) {
            return;
        }
        let _ = writeln!(
            out,
            "# HELP horizon_{name} {help}\n# TYPE horizon_{name} gauge"
        );
        for (labels, value) in values {
            if let Some(value) = value {
                let _ = writeln!(out, "horizon_{name}{labels} {value}");
            }
        }
    };
    let f = |v: &Value| v.as_f64();
    gauge(
        "up",
        "1 while the game runs and answers",
        &[(
            "",
            Some(f64::from(u8::from(
                phase == Phase::Running && !game.is_null(),
            ))),
        )],
    );
    gauge(
        "supervisor_uptime_seconds",
        "Seconds since horizon-server started",
        &[("", Some(shared.started.elapsed().as_secs() as f64))],
    );
    gauge(
        "crashes",
        "Game crashes since horizon-server started",
        &[("", Some(f64::from(crashes)))],
    );
    gauge(
        "tps",
        "Ticks per second over the last 5 seconds",
        &[("", f(&game["tps"]))],
    );
    gauge(
        "tps_target",
        "The tick rate the game aims for (/tick rate)",
        &[("", f(&game["target_tps"]))],
    );
    gauge(
        "mspt",
        "Milliseconds per tick: the average and the percentiles /tick query reports",
        &[
            ("{stat=\"average\"}", f(&game["mspt"]["average"])),
            ("{stat=\"p50\"}", f(&game["mspt"]["p50"])),
            ("{stat=\"p95\"}", f(&game["mspt"]["p95"])),
            ("{stat=\"p99\"}", f(&game["mspt"]["p99"])),
        ],
    );
    gauge(
        "players_online",
        "Players online",
        &[("", game["players"].as_array().map(|p| p.len() as f64))],
    );
    gauge(
        "players_max",
        "max-players",
        &[("", f(&game["max_players"]))],
    );
    gauge(
        "chunks_loaded",
        "Chunks loaded",
        &[("", f(&game["chunks"]))],
    );
    // By dimension, from the game's `levels`; a level the game does not count is left out, not
    // reported as 0.
    let by_dimension = |key: &str| -> Vec<(String, Option<f64>)> {
        game["levels"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|level| {
                let dimension = level["dimension"].as_str()?;
                Some((format!("{{dimension=\"{dimension}\"}}"), f(&level[key])))
            })
            .collect()
    };
    for (name, help, key) in [
        ("loaded_chunks", "Chunks loaded, by dimension", "chunks"),
        (
            "entities",
            "Entities (players and block entities apart), by dimension",
            "entities",
        ),
    ] {
        let values = by_dimension(key);
        let values: Vec<(&str, Option<f64>)> =
            values.iter().map(|(l, v)| (l.as_str(), *v)).collect();
        gauge(name, help, &values);
    }
    gauge(
        "memory_rss_bytes",
        "The game process's resident memory",
        &[("", f(&sample["rss_bytes"]))],
    );
    gauge(
        "cpu_percent",
        "The game process's CPU use (100 = one core)",
        &[("", f(&sample["cpu_percent"]))],
    );
    Response::text(200, "text/plain; version=0.0.4", out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn actions_become_console_lines() {
        let line = |a: Action, body: Value| a.line(&body);
        assert_eq!(
            line(Action::Kick, json!({ "name": "Kim0" })).unwrap(),
            "kick Kim0"
        );
        assert_eq!(
            line(
                Action::Ban,
                json!({ "name": "Lou0", "reason": " cheating " })
            )
            .unwrap(),
            "ban Lou0 cheating"
        );
        assert_eq!(
            line(
                Action::BanIp,
                json!({ "ip": "203.0.113.7", "reason": "spam bots" })
            )
            .unwrap(),
            "ban-ip 203.0.113.7 spam bots"
        );
        assert_eq!(
            line(Action::BanIp, json!({ "name": "Kim0" })).unwrap(),
            "ban-ip Kim0"
        );
        assert_eq!(
            line(Action::PardonIp, json!({ "ip": "::1" })).unwrap(),
            "pardon-ip ::1"
        );
        assert_eq!(
            line(Action::WhitelistAdd, json!({ "name": "Opal" })).unwrap(),
            "whitelist add Opal"
        );
        assert_eq!(
            line(Action::Whitelist, json!({ "enabled": false })).unwrap(),
            "whitelist off"
        );
        // Nothing can add a word or a second line to the command.
        assert!(line(Action::Ban, json!({ "name": "a b" })).is_err());
        assert!(line(Action::Op, json!({ "name": "" })).is_err());
        assert!(line(Action::Op, json!({ "name": "seventeen_letters" })).is_err());
        assert!(line(Action::Kick, json!({ "name": "Kim0", "reason": "a\nstop" })).is_err());
        assert!(line(Action::PardonIp, json!({ "ip": "Kim0" })).is_err());
        assert!(line(Action::Whitelist, json!({})).is_err());
    }

    #[test]
    fn stopped_actions_edit_file_backed_lists() {
        let dir = std::env::temp_dir().join(format!(
            "horizon-server-admin-stopped-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join(config::FILE), config::TEMPLATE).unwrap();
        config::update(&dir, "server", "online_mode", toml::Value::Boolean(false)).unwrap();
        config::update(&dir, "server", "whitelist", toml::Value::Boolean(false)).unwrap();
        let shared = Shared::with_install(&dir, None);
        shared.set_phase(Phase::Stopped);

        let call = |action, body| {
            let response = act(&shared, action, body);
            assert_eq!(response.status, 200, "{}", response.body);
            serde_json::from_str::<Value>(&response.body).unwrap()
        };
        assert_eq!(
            call(Action::Op, br#"{"name":"Alex"}"#),
            json!({ "changed": true, "output": ["Made Alex a server operator"] })
        );
        assert_eq!(
            call(Action::WhitelistAdd, br#"{"name":"Alex"}"#),
            json!({ "changed": true, "output": ["Added Alex to the whitelist"] })
        );
        assert_eq!(
            call(Action::Whitelist, br#"{"enabled":true}"#),
            json!({ "changed": true, "output": ["Whitelist is now turned on"] })
        );
        assert_eq!(
            call(Action::Deop, br#"{"name":"Alex"}"#),
            json!({ "changed": true, "output": ["Made Alex no longer a server operator"] })
        );
        assert_eq!(
            call(Action::WhitelistRemove, br#"{"name":"Alex"}"#),
            json!({ "changed": true, "output": ["Removed Alex from the whitelist"] })
        );
        assert!(
            !std::fs::read_to_string(dir.join("ops.json"))
                .unwrap()
                .contains("Alex")
        );
        assert!(
            !std::fs::read_to_string(dir.join("whitelist.json"))
                .unwrap()
                .contains("Alex")
        );
        assert!(config::Config::load(&dir).unwrap().server.whitelist);
        std::fs::remove_dir_all(&dir).unwrap();
    }

    fn moderation_reply(response: Response) -> Value {
        assert!(response.stream.is_none());
        json!({
            "status": response.status,
            "content_type": response.content_type,
            "headers": response.headers,
            "body": serde_json::from_str::<Value>(&response.body).unwrap(),
        })
    }

    #[test]
    fn moderation_replies_match_api_v1_goldens() {
        let golden: Value =
            serde_json::from_str(include_str!("../testdata/api-v1-moderation.json")).unwrap();
        let dir = std::env::temp_dir().join(format!(
            "horizon-server-api-moderation-goldens-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join(crate::config::FILE), crate::config::TEMPLATE).unwrap();
        crate::config::update(&dir, "server", "online_mode", toml::Value::Boolean(false)).unwrap();
        crate::config::update(&dir, "server", "whitelist", toml::Value::Boolean(false)).unwrap();
        let shared = Shared::with_install(&dir, None);
        shared.set_phase(Phase::Stopped);
        let call = |path: &str, body: &[u8]| {
            moderation_reply(crate::api::route(
                &shared,
                &crate::http::Request {
                    method: "POST".into(),
                    path: path.into(),
                    query: String::new(),
                    headers: Vec::new(),
                    body: body.to_vec(),
                },
            ))
        };
        let check = |case: &str, path: &str, body: &[u8]| {
            assert_eq!(call(path, body), golden[case], "{case}");
        };

        check("op", "/api/v1/players/op", br#"{"name":"Alex"}"#);
        check("op_again", "/api/v1/players/op", br#"{"name":"Alex"}"#);
        check("deop", "/api/v1/players/deop", br#"{"name":"Alex"}"#);
        check("deop_again", "/api/v1/players/deop", br#"{"name":"Alex"}"#);
        check(
            "whitelist_add",
            "/api/v1/whitelist/add",
            br#"{"name":"Alex"}"#,
        );
        check(
            "whitelist_add_again",
            "/api/v1/whitelist/add",
            br#"{"name":"Alex"}"#,
        );
        check("whitelist_on", "/api/v1/whitelist", br#"{"enabled":true}"#);
        check(
            "whitelist_on_again",
            "/api/v1/whitelist",
            br#"{"enabled":true}"#,
        );
        check(
            "whitelist_remove",
            "/api/v1/whitelist/remove",
            br#"{"name":"Alex"}"#,
        );
        check(
            "whitelist_remove_again",
            "/api/v1/whitelist/remove",
            br#"{"name":"Alex"}"#,
        );
        for (case, path, body) in [
            (
                "kick_stopped",
                "/api/v1/players/kick",
                br#"{"name":"Alex"}"#.as_slice(),
            ),
            (
                "ban_stopped",
                "/api/v1/players/ban",
                br#"{"name":"Alex"}"#.as_slice(),
            ),
            (
                "pardon_stopped",
                "/api/v1/players/pardon",
                br#"{"name":"Alex"}"#.as_slice(),
            ),
            (
                "ban_ip_stopped",
                "/api/v1/players/ban-ip",
                br#"{"ip":"203.0.113.7"}"#.as_slice(),
            ),
            (
                "pardon_ip_stopped",
                "/api/v1/players/pardon-ip",
                br#"{"ip":"203.0.113.7"}"#.as_slice(),
            ),
        ] {
            check(case, path, body);
        }
        check("malformed", "/api/v1/players/op", b"not json");
        check("bad_name", "/api/v1/players/op", br#"{"name":"a b"}"#);
        check(
            "bad_reason",
            "/api/v1/players/kick",
            br#"{"name":"Alex","reason":"first\nsecond"}"#,
        );
        check("bad_ip", "/api/v1/players/pardon-ip", br#"{"ip":"Alex"}"#);
        check("bad_whitelist", "/api/v1/whitelist", br#"{}"#);
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn build_record_is_only_provenance() {
        let none = built_with(None);
        assert_eq!(
            (none["engine"]["found"].clone(), none["native"].clone()),
            (json!(false), json!([]))
        );
        let record = r#"{"base":"v1","horizon":"abc","target":"server","hooks":326,"mods":[{"id":"m","version":"1.0","sha256":"ff"}]}"#;
        let some = built_with(Some(record));
        assert_eq!(some["engine"]["target"], "server");
        assert_eq!(some["engine"]["found"], true);
        assert_eq!(
            some["native"],
            json!([{ "id": "m", "version": "1.0", "sha256": "ff" }])
        );
        // A release has no record's mods; a broken file is no mods.
        assert_eq!(built_with(Some("{}"))["native"], json!([]));
        assert_eq!(built_with(Some("nope"))["native"], json!([]));
    }

    #[test]
    fn mods_use_runtime_inventory_and_report_unavailability() {
        use std::{
            io::{BufRead, BufReader, Write},
            net::TcpListener,
            time::Duration,
        };

        let dir = std::env::temp_dir().join(format!(
            "horizon-server-runtime-mods-{}",
            std::process::id()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join(config::FILE), config::TEMPLATE).unwrap();
        config::update(&dir, "engine", "path", toml::Value::String("engine".into())).unwrap();
        std::fs::write(dir.join("engine"), "test program").unwrap();
        std::fs::write(
            dir.join("native-mods.json"),
            r#"{"horizon":"old-build","mods":[{"id":"built_only","version":"0","sha256":"ff"}]}"#,
        )
        .unwrap();
        let shared = Shared::with_install(&dir, None);
        let call = || {
            crate::api::route(
                &shared,
                &crate::http::Request {
                    method: "GET".into(),
                    path: "/api/v1/mods".into(),
                    query: String::new(),
                    headers: Vec::new(),
                    body: Vec::new(),
                },
            )
        };
        shared.set_phase(Phase::Stopped);
        let stopped = call();
        assert_eq!(stopped.status, 409);
        assert!(stopped.body.contains("isn't running"));
        assert!(!stopped.body.contains("built_only"));

        shared.set_phase(Phase::Running);
        // A running phase with a missing control endpoint is not an empty inventory.
        assert_eq!(call().status, 409);
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let path = launch::control_path(&dir);
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(
            path,
            json!({"port": listener.local_addr().unwrap().port(), "token": "test-token"})
                .to_string(),
        )
        .unwrap();
        let inventory = json!([
            {"id": "native_loaded", "version": "2"},
            {"id": "wasm_loaded", "version": "3"},
            {"id": "content_loaded", "version": "4"},
        ]);
        // The mock owns only the transport: the real endpoint must authenticate and issue the query.
        let replies = [
            Some(json!({"mods": inventory})),
            Some(json!({"mods": []})),
            Some(json!({"error": "unknown request"})),
            Some(json!({"mods": [{"id": "broken", "version": null}]})),
            None,
        ];
        let peer = std::thread::spawn(move || {
            for reply in replies {
                let (mut socket, _) = listener.accept().unwrap();
                socket
                    .set_read_timeout(Some(Duration::from_secs(5)))
                    .unwrap();
                let mut reader = BufReader::new(socket.try_clone().unwrap());
                let mut line = String::new();
                reader.read_line(&mut line).unwrap();
                assert_eq!(line.trim(), "auth test-token");
                writeln!(socket, "{{\"ok\":true}}").unwrap();
                line.clear();
                reader.read_line(&mut line).unwrap();
                assert_eq!(line.trim(), "server-mods");
                if let Some(reply) = reply {
                    writeln!(socket, "{reply}").unwrap();
                }
            }
        });
        let running = call();
        assert_eq!(running.status, 200);
        let body: Value = serde_json::from_str(&running.body).unwrap();
        assert_eq!(body["mods"], inventory);
        assert_eq!(body["provenance"]["engine"]["horizon"], "old-build");
        assert_eq!(body["provenance"]["native"][0]["id"], "built_only");
        assert!(body.get("native").is_none());
        let empty = call();
        assert_eq!(empty.status, 200);
        let empty: Value = serde_json::from_str(&empty.body).unwrap();
        assert_eq!(empty["mods"], json!([]));
        assert_eq!(empty["provenance"]["native"][0]["id"], "built_only");
        for _ in 0..3 {
            let unavailable = call();
            assert_eq!(unavailable.status, 409);
            assert!(!unavailable.body.contains("built_only"));
            let body: Value = serde_json::from_str(&unavailable.body).unwrap();
            assert!(body.get("mods").is_none());
        }
        peer.join().unwrap();
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn players_and_metrics_without_a_game() {
        let dir = std::env::temp_dir().join(format!("horizon-server-admin-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(
            dir.join("banned-players.json"),
            r#"[{"uuid":"00000000-0000-0000-0000-000000000001","name":"Lou0","created":"2026-10-31 12:00:00 +0000","source":"Server","expires":"forever","reason":"cheating"}]"#,
        )
        .unwrap();
        std::fs::write(dir.join("server.properties"), "white-list=true\n").unwrap();
        let shared = Shared::with_install(&dir, None);
        let players: Value = serde_json::from_str(&players(&shared).body).unwrap();
        assert_eq!(players["online"], json!([]));
        assert_eq!(players["whitelist"]["enabled"], true);
        assert_eq!(players["bans"][0]["name"], "Lou0");
        assert_eq!(players["bans"][0]["reason"], "cheating");
        assert_eq!(players["bans"][0]["expires"], Value::Null);
        let text = prometheus(&shared).body;
        assert!(
            text.contains("# TYPE horizon_up gauge\nhorizon_up 0\n"),
            "{text}"
        );
        assert!(!text.contains("horizon_tps "), "no game, no TPS: {text}");
        shared.state.lock().unwrap().sample = json!({
            "rss_bytes": 1000, "cpu_percent": 12.5,
            "game": { "tps": 20.0, "mspt": { "average": 3.5, "p50": 3.0, "p95": 6.0, "p99": 9.0 },
                      "players": [{ "name": "Kim0" }], "max_players": 20, "chunks": 441 },
        });
        let text = prometheus(&shared).body;
        for line in [
            "horizon_tps 20\n",
            "horizon_mspt{stat=\"p95\"} 6\n",
            "horizon_players_online 1\n",
            "horizon_memory_rss_bytes 1000\n",
        ] {
            assert!(text.contains(line), "{line} in {text}");
        }
        assert!(
            !text.contains("horizon_entities"),
            "no levels, no counts: {text}"
        );
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn chunks_and_entities_are_reported_by_dimension() {
        let dir =
            std::env::temp_dir().join(format!("horizon-server-levels-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let shared = Shared::with_install(&dir, None);
        shared.state.lock().unwrap().sample = json!({
            "game": { "tps": 20.0, "chunks": 441, "levels": [
                { "dimension": "minecraft:overworld", "chunks": 441, "entities": 37 },
                { "dimension": "minecraft:the_nether", "chunks": 25, "entities": 0 },
                { "dimension": "minecraft:the_end" },
            ] },
        });
        let text = prometheus(&shared).body;
        for line in [
            "# TYPE horizon_loaded_chunks gauge
",
            "horizon_loaded_chunks{dimension=\"minecraft:overworld\"} 441
",
            "horizon_loaded_chunks{dimension=\"minecraft:the_nether\"} 25
",
            "# TYPE horizon_entities gauge
",
            "horizon_entities{dimension=\"minecraft:overworld\"} 37
",
            "horizon_entities{dimension=\"minecraft:the_nether\"} 0
",
        ] {
            assert!(text.contains(line), "{line} in {text}");
        }
        // A level the game gave no count for has no line, rather than a 0.
        assert!(!text.contains("the_end"), "{text}");
        std::fs::remove_dir_all(&dir).unwrap();
    }
}
